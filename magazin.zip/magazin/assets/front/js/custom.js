jQuery(document).ready(function() {
  jQuery("ul.tabs359").tabs(".tab-inner-warp359",{effect:"slide",fadeInSpeed:100});
});
