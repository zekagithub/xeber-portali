<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Dtbs extends CI_Model{
	function kontrol($email,$sifre){
		$cavab=$this->db->select('*')
		->from('admin')->where('email',$email)
		->where('sifre',$sifre)
		->get()->row();
		return $cavab;

	}
	function cedvel($from)
	{
		$cavab=$this->db->select('*')->from($from)
		->order_by('id','desc')->get()->result_array();
		return $cavab;
	}
	function cek($id,$from){
		$cavab=$this->db->select('*')->from($from)
		->where('id',$id)->get()->row_array();
		return $cavab;
	}
	function guncelle($data=array(),$id,$where,$from){
		$cavab=$this->db->where($where,$id)->update($from,$data);
		return $cavab;
	}
	 function elave($from,$data=array()){
		$cavab=$this->db->insert($from,$data);
		return $cavab;
	}
	function sil($id,$where,$from){
		$cavab=$this->db->delete($from,array($where=>$id));
		return $cavab;
	}
	function xebersayi(){
		$cavab=$this->db->select('*')->from('xeberler')->where('status','1')
		->count_all_results();
		return $cavab;
	}
function xebercek($per,$set){
	$cavab=$this->db->select('*')->from('xeberler')
	->where('status','1')->order_by('id','desc')
	->limit($per,$set)->get()->result_array();
	return $cavab;

}
function siyasetsayi(){
		$cavab=$this->db->select('*')->from('xeberler')
		->where('katID','7')
		->where('status','1')
		->count_all_results();
		return $cavab;
	}
function siyasetcek($per,$set){
	$cavab=$this->db->select('*')->from('xeberler')
	->where('katID','7')
	->where('status','1')->order_by('id','desc')
	->limit($per,$set)->get()->result_array();
	return $cavab;
}
function ekonomisayi(){
		$cavab=$this->db->select('*')->from('xeberler')
		->where('katID','8')
		->where('status','1')
		->count_all_results();
		return $cavab;
	}
function ekonomicek($per,$set){
	$cavab=$this->db->select('*')->from('xeberler')
	->where('katID','8')
	->where('status','1')->order_by('id','desc')
	->limit($per,$set)->get()->result_array();
	return $cavab;
}

function medeniyyetsayi(){
		$cavab=$this->db->select('*')->from('xeberler')
		->where('katID','6')
		->where('status','1')
		->count_all_results();
		return $cavab;
	}
function medeniyyetcek($per,$set){
	$cavab=$this->db->select('*')->from('xeberler')
	->where('katID','6')
	->where('status','1')->order_by('id','desc')
	->limit($per,$set)->get()->result_array();
	return $cavab;
}
function magazinsayi(){
		$cavab=$this->db->select('*')->from('xeberler')
		->where('katID','10')
		->where('status','1')
		->count_all_results();
		return $cavab;
	}
function magazincek($per,$set){
	$cavab=$this->db->select('*')->from('xeberler')
	->where('katID','10')
	->where('status','1')->order_by('id','desc')
	->limit($per,$set)->get()->result_array();
	return $cavab;
}
function idmansayi(){
		$cavab=$this->db->select('*')->from('xeberler')
		->where('katID','9')
		->where('status','1')
		->count_all_results();
		return $cavab;
	}
function idmancek($per,$set){
	$cavab=$this->db->select('*')->from('xeberler')
	->where('katID','9')
	->where('status','1')->order_by('id','desc')
	->limit($per,$set)->get()->result_array();
	return $cavab;
}
function maraqlisayi(){
	$cavab=$this->db->select('*')->from('xeberler')
	->where('katID','11')
	->where('status','1')
	->count_all_results();
	return $cavab;
}
function maraqlicek($per,$set){
	$cavab=$this->db->select('*')->from('xeberler')
	->where('katID','11')
	->where('status','1')
	->order_by('id','desc')
	->limit($per,$set)->get()->result_array();
	return $cavab;
}
function xeberdetal($tool){
	$cavab=$this->db->select('*')->from('xeberler')
	->where('tool',$tool)
	->where('status','1')
	->get()->row_array();
	return $cavab;
}
function hit($tool){
$cavab=$this->db->select('*')->from('xeberler')
->where('status','1')->where('tool',$tool)
->get()->row_array();
return $cavab;
}
function mesajupdate($id,$data=array()){
	$cavab=$this->db->where('id',$id)->update('mesaj',$data);
	return $cavab;
}
}
?>