<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Anasehife extends CI_Controller{
	public function index(){
		$cavab=$this->dtbs->xebersayi();
		$this->load->library('pagination');
		$config['base_url']=base_url().'anasehife';
		$config['total_rows']=$cavab;
		$config['per_page']=10;
	    $config['url_segment']=3;
		$config['full_tag_open']='<div class="pagination">';
		$config['full_tag_close']='</div>';
		$config['first_link']=false;
		$config['first_tag_open']='<a class="first">';
		$config['first_tag_close']='</a>';
		$config['Last_link']=false;
		$config['Last_tag_open']='<a class="last">';
		$config['Last_tag_close']='</a>';
		$config['next_link']='&raquo;';

		$config['prev_link']='&laquo;';
		$config['prev_tag_open']='<a class="page">';
		$config['prev_tag_close']='</a>';
		$config['cur_tag_open']='<span class="current">';
		$config['cur_tag_close']='</span>';
		$this->pagination->initialize($config);
		$data['linkler']=$this->pagination->create_links();
		$data['bilgi']=$this->dtbs->xebercek($config['per_page'],$this->uri->segment(2,0));
		$this->load->view('anasehife',$data);
	}
	public function siyaset(){
		$cavab=$this->dtbs->siyasetsayi();
		$this->load->library('pagination');
		$config['base_url']=base_url().'anasehife/siyaset';
		$config['total_rows']=$cavab;
		$config['per_page']=5;
	    $config['url_segment']=3;
		$config['full_tag_open']='<div class="pagination">';
		$config['full_tag_close']='</div>';
		$config['first_link']=false;
		$config['first_tag_open']='<a class="first">';
		$config['first_tag_close']='</a>';
		$config['Last_link']=false;
		$config['Last_tag_open']='<a class="last">';
		$config['Last_tag_close']='</a>';
		$config['next_link']='&raquo;';

		$config['prev_link']='&laquo;';
		$config['prev_tag_open']='<a class="page">';
		$config['prev_tag_close']='</a>';
		$config['cur_tag_open']='<span class="current">';
		$config['cur_tag_close']='</span>';
		$this->pagination->initialize($config);
		$data['linkler']=$this->pagination->create_links();
		$data['bilgi']=$this->dtbs->siyasetcek($config['per_page'],$this->uri->segment(3,0));

		$this->load->view('front/siyaset/anasehife',$data);
	}
	public function ekonomi(){
		$cavab=$this->dtbs->ekonomisayi();
		$this->load->library('pagination');
		$config['base_url']=base_url().'anasehife/ekonomi';
		$config['total_rows']=$cavab;
		$config['per_page']=5;
	    $config['url_segment']=3;
		$config['full_tag_open']='<div class="pagination">';
		$config['full_tag_close']='</div>';
		$config['first_link']=false;
		$config['first_tag_open']='<a class="first">';
		$config['first_tag_close']='</a>';
		$config['Last_link']=false;
		$config['Last_tag_open']='<a class="last">';
		$config['Last_tag_close']='</a>';
		$config['next_link']='&raquo;';

		$config['prev_link']='&laquo;';
		$config['prev_tag_open']='<a class="page">';
		$config['prev_tag_close']='</a>';
		$config['cur_tag_open']='<span class="current">';
		$config['cur_tag_close']='</span>';
		$this->pagination->initialize($config);
		$data['linkler']=$this->pagination->create_links();
		$data['bilgi']=$this->dtbs->ekonomicek($config['per_page'],$this->uri->segment(3,0));

		$this->load->view('front/ekonomi/anasehife',$data);
	}
		public function medeniyyet(){
		$cavab=$this->dtbs->medeniyyetsayi();
		$this->load->library('pagination');
		$config['base_url']=base_url().'anasehife/medeniyyet';
		$config['total_rows']=$cavab;
		$config['per_page']=5;
	    $config['url_segment']=3;
		$config['full_tag_open']='<div class="pagination">';
		$config['full_tag_close']='</div>';
		$config['first_link']=false;
		$config['first_tag_open']='<a class="first">';
		$config['first_tag_close']='</a>';
		$config['Last_link']=false;
		$config['Last_tag_open']='<a class="last">';
		$config['Last_tag_close']='</a>';
		$config['next_link']='&raquo;';
		$config['prev_link']='&laquo;';
		$config['prev_tag_open']='<a class="page">';
		$config['prev_tag_close']='</a>';
		$config['cur_tag_open']='<span class="current">';
		$config['cur_tag_close']='</span>';
		$this->pagination->initialize($config);
		$data['linkler']=$this->pagination->create_links();
		$data['bilgi']=$this->dtbs->medeniyyetcek($config['per_page'],$this->uri->segment(3,0));

		$this->load->view('front/medeniyyet/anasehife',$data);
	}
	
		public function magazin(){
		$cavab=$this->dtbs->magazinsayi();
		$this->load->library('pagination');
		$config['base_url']=base_url().'anasehife/magazin';
		$config['total_rows']=$cavab;
		$config['per_page']=5;
	    $config['url_segment']=3;
		$config['full_tag_open']='<div class="pagination">';
		$config['full_tag_close']='</div>';
		$config['first_link']=false;
		$config['first_tag_open']='<a class="first">';
		$config['first_tag_close']='</a>';
		$config['Last_link']=false;
		$config['Last_tag_open']='<a class="last">';
		$config['Last_tag_close']='</a>';
		$config['next_link']='&raquo;';
		$config['prev_link']='&laquo;';
		$config['prev_tag_open']='<a class="page">';
		$config['prev_tag_close']='</a>';
		$config['cur_tag_open']='<span class="current">';
		$config['cur_tag_close']='</span>';
		$this->pagination->initialize($config);
		$data['linkler']=$this->pagination->create_links();
		$data['bilgi']=$this->dtbs->magazincek($config['per_page'],$this->uri->segment(4,0));
		$this->load->view('front/magazin/anasehife',$data);

	}
		public function idman(){
		$cavab=$this->dtbs->idmansayi();
		$this->load->library('pagination');
		$config['base_url']=base_url().'anasehife/idman';
		$config['total_rows']=$cavab;
		$config['per_page']=5;
	    $config['url_segment']=3;
		$config['full_tag_open']='<div class="pagination">';
		$config['full_tag_close']='</div>';
		$config['first_link']=false;
		$config['first_tag_open']='<a class="first">';
		$config['first_tag_close']='</a>';
		$config['Last_link']=false;
		$config['Last_tag_open']='<a class="last">';
		$config['Last_tag_close']='</a>';
		$config['next_link']='&raquo;';
		$config['prev_link']='&laquo;';
		$config['prev_tag_open']='<a class="page">';
		$config['prev_tag_close']='</a>';
		$config['cur_tag_open']='<span class="current">';
		$config['cur_tag_close']='</span>';
		$this->pagination->initialize($config);
		$data['linkler']=$this->pagination->create_links();
		$data['bilgi']=$this->dtbs->idmancek($config['per_page'],$this->uri->segment(3,0));
		$this->load->view('front/idman/anasehife',$data);

	}
	public function maraqli(){
		$cavab=$this->dtbs->maraqlisayi();
		$this->load->library('pagination');
		$config['base_url']=base_url().'anasehife/maraqli';
		$config['total_rows']=$cavab;
		$config['per_page']=5;
	    $config['url_segment']=3;
		$config['full_tag_open']='<div class="pagination">';
		$config['full_tag_close']='</div>';
		$config['first_link']=false;
		$config['first_tag_open']='<a class="first">';
		$config['first_tag_close']='</a>';
		$config['Last_link']=false;
		$config['Last_tag_open']='<a class="last">';
		$config['Last_tag_close']='</a>';
		$config['next_link']='&raquo;';
		$config['prev_link']='&laquo;';
		$config['prev_tag_open']='<a class="page">';
		$config['prev_tag_close']='</a>';
		$config['cur_tag_open']='<span class="current">';
		$config['cur_tag_close']='</span>';
		$this->pagination->initialize($config);
		$data['linkler']=$this->pagination->create_links();
		$data['bilgi']=$this->dtbs->maraqlicek($config['per_page'],$this->uri->segment(3,0));
		$this->load->view('front/maraqli/anasehife',$data);

	}
	public function siyasetdetal($tool){
    $cavab=$this->dtbs->hit($tool);
    $hit=$cavab['hit']+1;
    $id=$cavab['id'];
    $data=array('id'=>$id,'hit'=>$hit);
    $this->dtbs->guncelle($data,$id,'id','xeberler');



    $cavab=$this->dtbs->xeberdetal($tool);
	$data['bilgi']=$cavab;
	$this->load->view('front/siyaset/detal/anasehife',$data);


	}

public function ekonomidetal($tool){
	$cavab=$this->dtbs->hit($tool);
    $hit=$cavab['hit']+1;
    $id=$cavab['id'];
    $data=array('id'=>$id,'hit'=>$hit);
    $this->dtbs->guncelle($data,$id,'id','xeberler');


	$cavab=$this->dtbs->xeberdetal($tool);
	$data['bilgi']=$cavab;
	$this->load->view('front/ekonomi/detal/anasehife',$data);
}
public function medeniyyetdetal($tool){
	$cavab=$this->dtbs->hit($tool);
    $hit=$cavab['hit']+1;
    $id=$cavab['id'];
    $data=array('id'=>$id,'hit'=>$hit);
    $this->dtbs->guncelle($data,$id,'id','xeberler');

	$cavab=$this->dtbs->xeberdetal($tool);
	$data['bilgi']=$cavab;
	$this->load->view('front/medeniyyet/detal/anasehife',$data);
}
public function magazindetal($tool){
	$cavab=$this->dtbs->hit($tool);
    $hit=$cavab['hit']+1;
    $id=$cavab['id'];
    $data=array('id'=>$id,'hit'=>$hit);
    $this->dtbs->guncelle($data,$id,'id','xeberler');

	$cavab=$this->dtbs->xeberdetal($tool);
	$data['bilgi']=$cavab;
	$this->load->view('front/magazin/detal/anasehife',$data);
}
public function idmandetal($tool){
	$cavab=$this->dtbs->hit($tool);
    $hit=$cavab['hit']+1;
    $id=$cavab['id'];
    $data=array('id'=>$id,'hit'=>$hit);
    $this->dtbs->guncelle($data,$id,'id','xeberler');

	$cavab=$this->dtbs->xeberdetal($tool);
	$data['bilgi']=$cavab;
	$this->load->view('front/idman/detal/anasehife',$data);
}
public function maraqlidetal($tool){
	$cavab=$this->dtbs->hit($tool);
    $hit=$cavab['hit']+1;
    $id=$cavab['id'];
    $data=array('id'=>$id,'hit'=>$hit);
    $this->dtbs->guncelle($data,$id,'id','xeberler');

	$cavab=$this->dtbs->xeberdetal($tool);
	$data['bilgi']=$cavab;
	$this->load->view('front/maraqli/detal/anasehife',$data);
}
public function comment(){
$this->form_validation->set_rules('adsoyad','ad ve soyad','trim|required|min_length[5]|xss_clean');
$this->form_validation->set_rules('email','email adresi','trim|required|valid_email|xss_clean');
$this->form_validation->set_rules('yorum','Serh','trim|required|xss_clean');
$xeta=array(
'required'=>"{field} yerleri doldurun",
'min_length'=>"ad ve soyad en az 5 herifden ibaret olmalidir.!!",
'valid_email'=>"email adresini duzgun yazin.!!");
$this->form_validation->set_message($xeta);
if ($this->form_validation->run() == FALSE) {
	$this->session->set_flashdata('xeta','<div class="quote">
<blockquote>
<div class="quote-inner">
<div class="post-inner-content">
<p>'.$xeta['xeta'].'</p>
</div>
</div>
</blockquote>
</div>');

redirect($_SERVER['HTTP_REFERER']);
}else{
	$data=array(
		'adi'=>$adsoyad=$this->input->post('adsoyad'),
		'email'  =>$email=$this->input->post('email'),
		'serh'=>$yorum=$this->input->post('yorum'),
		'movzu_id'=>$movzu_id=$this->input->post('movzuid'),
		'movzu_tool'=>$movzu_tool=$this->input->post('movzutool'),
		'movzu_kat'=>$movzu_kat=$this->input->post('movzukat'),
		'ip'=>$ip=$this->input->post('ip'),
		'status'=>$status=0,
		'tarix'=>$tarix=date('d-m-Y')

	);
	$cavab=$this->dtbs->elave('serh',$data);
	if ($cavab) {
$this->session->set_flashdata('xeta','<div class="quote">
<blockquote>
<div class="quote-inner">
<div class="post-inner-content">
<p>tesekkur edirik..serhiniz elave edilecek</p>
</div>
</div>
</blockquote>
</div>');
redirect($_SERVER['HTTP_REFERER']);

	}
	else{
		$this->session->set_flashdata('xeta','<div class="quote">
<blockquote>
<div class="quote-inner">
<div class="post-inner-content">
<p>Sehf</p>
<p>Serh gonderilmedi. Daha Sonra Tekrar edin!!</p>
</div>
</div>
</blockquote>
</div>');
 redirect($_SERVER['HTTP_REFERER']);


	}

}

}
//commentin sonu


public function haqqimizda(){
	$this->load->view('front/haqqimizda/anasehife');
}
public function elaqe(){
	$this->load->view('front/elaqe/anasehife');
}
public function mesaj(){
$this->form_validation->set_rules('adi','ad ve soyad','trim|required|min_length[5]|xss_clean');
$this->form_validation->set_rules('email','email adresi','trim|required|valid_email|xss_clean');
$this->form_validation->set_rules('movzu','movzu','trim|required|xss_clean');
$this->form_validation->set_rules('mesaj','mesaj','trim|required|xss_clean');

$xeta=array(
'required'=>"{field} yerleri doldurun",
'min_length'=>"ad ve soyad en az 5 herifden ibaret olmalidir.!!",
'valid_email'=>"email adresini duzgun yazin.!!");
$this->form_validation->set_message($xeta);
if ($this->form_validation->run() == FALSE) {
	$this->session->set_flashdata('xeta','<div class="quote">
<blockquote>
<div class="quote-inner">
<div class="post-inner-content">
<p>'.$xeta['xeta'].'</p>
</div>
</div>
</blockquote>
</div>');

redirect($_SERVER['HTTP_REFERER']);
}else{
	$data=array(
		'adi'=>$adi=$this->input->post('adi'),
		'email'  =>$email=$this->input->post('email'),
		'movzu'=>$movzu=$this->input->post('movzu'),
		'mesaj'=>$mesaj=$this->input->post('mesaj'),
		'status'=>$status=0,
		'tarix'=>$tarix=date('d-m-Y')

	);
	$cavab=$this->dtbs->elave('mesaj',$data);
	if ($cavab) {
$this->session->set_flashdata('xeta','<div class="quote">
<blockquote>
<div class="quote-inner">
<div class="post-inner-content">
<p>Mesajiniz gonderildi...</p>
</div>
</div>
</blockquote>
</div>');
redirect($_SERVER['HTTP_REFERER']);

	}
	else{
		$this->session->set_flashdata('xeta','<div class="quote">
<blockquote>
<div class="quote-inner">
<div class="post-inner-content">
<p>Sehf</p>
<p>Mesaj gonderilmedi. Daha Sonra Tekrar edin!!</p>
</div>
</div>
</blockquote>
</div>');
 redirect($_SERVER['HTTP_REFERER']);


	}

}
}
}

?>
   

 