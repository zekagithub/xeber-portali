<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	function protect(){
		$giris=$this->session->userdata('giris');
		if (!$giris) {
			redirect('admin');		}
	}

	 function index()
	{
		$giris=$this->session->userdata('giris');
		if ($giris) {
			redirect('admin/anasehife');
		}
		$this->load->view('back/giris');
	}
	public function giriset()
	{
		$email=$this->input->post('email');
		$sifre=$this->input->post('sifre');
		$kontrol=$this->dtbs->kontrol($email,$sifre);
		if ($kontrol) {
          $this->session->set_userdata('giris',true);
          redirect('admin/anasehife');
      }
       
 	
 	else{
 		$this->session->set_flashdata('veziyyet','<div class="alert alert-danger"><h4>Istifadeci adiniz yanlisdir...</h4></div>');
 		redirect('admin');
     

      	}

}
  public function anasehife()
              {
             $this->protect();
	           $this->load->view('back/anasehife');
                }

   public function cixis()
   {
   	$this->session->sess_destroy();
   	redirect('admin');

    }
    //site admin umumui gorulecek islerin bitiisi
    //site ayarlari baslangic
    public function ayarlar()
    {
    	$cavab=$this->dtbs->cedvel('site_ayarlari');
    	$data['bilgi']=$cavab;
    	$this->load->view('back/ayarlar/anasehife',$data);
    
    }
public function ayardeyisdir($id)
{
  $cavab=$this->dtbs->cek($id,'site_ayarlari');
  $data['bilgi']=$cavab;
  $this->load->view('back/ayarlar/edit/anasehife',$data);
 }
 public function ayarguncelle(){
  $data=array(
    'id'          =>$id=$this->input->post('id'),
    'title'       =>$title=$this->input->post('basliq'),
    'site_mail'   =>$mail=$this->input->post('email'),
    'site_telefon'=>$telefon=$this->input->post('telefon'),
    'site_desc'=>$aciqlama=$this->input->post('desc'),
    'site_keyw'=>$acar=$this->input->post('keyw'),

    'site_bilgi'  =>$melumat=$this->input->post('melumat'),
    'site_adres'  =>$adres  =$this->input->post('adres'),

  );
  $cavab=$this->dtbs->guncelle($data,$id,'id','site_ayarlari');
  if ($cavab) {
        $this->session->set_flashdata('veziyyet','<div class="alert alert-success"><h4>Sayt ayarlarini deyisdirdiniz...</h4></div>');
        redirect('admin/ayarlar');
     
  }else{
        $this->session->set_flashdata('veziyyet','<div class="alert alert-danger"><h4>Deyisdirilmedi!!!</h4></div>');
        redirect('admin/ayarlar');
       }
  


   }
   //sayt ayarlarinin bitisi
   //sosial-mediya ayarlarinin baslangiici
   public function sosialmediya(){
     $cavab=$this->dtbs->cedvel('sosialmediya');
      $data['bilgi']=$cavab;
      $this->load->view('back/sosialmediya/anasehife',$data);
   }
public function smediyaelave(){
   $this->load->view('back/sosialmediya/add/anasehife');

   }
public function smediyaelaveetme(){
  $data=array(
'title'=>$basliq=$this->input->post('basliq'),
'url'=>$url=$this->input->post('url'),
'status'=>1

  );
  $cavab=$this->dtbs->elave('sosialmediya',$data);
  if ($cavab) {
 $this->session->set_flashdata('status','<div class="alert alert-success"><h4>Elave etdiniz...</h4></div>');
        redirect('admin/sosialmediya');
          }else{
            $this->session->set_flashdata('status','<div class="alert alert-danger"><h4>Sehv!!!Elave edilmedi</h4></div>');
        redirect('admin/sosialmediya');

          }

}
public function smediyadeyis($id)
{
    $cavab=$this->dtbs->cek($id,'sosialmediya');
     $data['bilgi']=$cavab;
  $this->load->view('back/sosialmediya/edit/anasehife',$data);
    

   }
   public function smediyaguncelle(){
    $data=array(
           'id'          =>$id=$this->input->post('id'),
           'title' =>$basliq=$this->input->post('basliq'),
          'url'   =>$url=$this->input->post('url'),
          'status'=>$status=$this->input->post('status')


    );
     $cavab=$this->dtbs->guncelle($data,$id,'id','sosialmediya');
     if ($cavab) {
        $this->session->set_flashdata('status','<div class="alert alert-success"><h4>Sayt ayarlarini deyisdirdiniz...</h4></div>');
        redirect('admin/sosialmediya');


   }else{
        $this->session->set_flashdata('status','<div class="alert alert-danger"><h4>Deyisdirilmedi!!!</h4></div>');
        redirect('admin/sosialmediya');
       }




}
public function smediyasil($id,$where,$from){
  $cavab=$this->dtbs->sil($id,$where,$from);
  if ($cavab) {
        $this->session->set_flashdata('status','<div class="alert alert-success"><h4> Silindi...</h4></div>');
        redirect('admin/sosialmediya');


   }else{
        $this->session->set_flashdata('status','<div class="alert alert-danger"><h4>Silinmedi!!!</h4></div>');
        redirect('admin/sosialmediya');
       }







}
public function smediyaset(){
  $id=$this->input->post('id');
  $status=($this->input->post('status')=="true") ? 1 : 0 ;
  $this->db->where('id',$id)->update('sosialmediya',array('status'=>$status));
}
//sosial mediya bitisi
//kateqoriyanin baslangici

public function kateqoriya(){
  $cavab=$this->dtbs->cedvel('kateqoriya');
      $data['bilgi']=$cavab;
      $this->load->view('back/kateqoriya/anasehife',$data);

}
public function kateqoriyaelave(){
  $this->load->view('back/kateqoriya/add/anasehife');
}
public function kateqoriyaelaveetme(){
   $data=array(
'title'=>$basliq=$this->input->post('basliq'),
'tool'=>permalink($basliq)

  );
  $cavab=$this->dtbs->elave('kateqoriya',$data);
  if ($cavab) {
 $this->session->set_flashdata('veziyyet','<div class="alert alert-success"><h4>Elave etdiniz...</h4></div>');
        redirect('admin/kateqoriya');
          }else{
            $this->session->set_flashdata('veziyyet','<div class="alert alert-danger"><h4>Sehv!!!Elave edilmedi</h4></div>');
        redirect('admin/kateqoriya');

          }



}
public function kateqoriyadeyis($id)
{
    $cavab=$this->dtbs->cek($id,'kateqoriya');
     $data['bilgi']=$cavab;
  $this->load->view('back/kateqoriya/edit/anasehife',$data);
    

   }
   public function kateqoriyaguncelle(){
    $data=array(
           'id'          =>$id=$this->input->post('id'),
           'title' =>$basliq=$this->input->post('basliq'),
           'tool'=>permalink($basliq)

          


    );
     $cavab=$this->dtbs->guncelle($data,$id,'id','kateqoriya');
     if ($cavab) {
        $this->session->set_flashdata('veziyyet','<div class="alert alert-success"><h4> kateqoriyani deyisdirdiniz...</h4></div>');
        redirect('admin/kateqoriya');


   }else{
        $this->session->set_flashdata('veziyyet','<div class="alert alert-danger"><h4>Deyisdirilmedi!!!</h4></div>');
        redirect('admin/kateqoriiya');
       }




}
public function kateqoriyasil($id,$where,$from){
  $cavab=$this->dtbs->sil($id,$where,$from);
  if ($cavab) {
        $this->session->set_flashdata('veziyyet','<div class="alert alert-success"><h4> Silindi...</h4></div>');
        redirect('admin/kateqoriya');


   }else{
        $this->session->set_flashdata('veziyyet','<div class="alert alert-danger"><h4>Silinmedi!!!</h4></div>');
        redirect('admin/kateqoriya');
       }


}
//kateqoriya bitisi
//xeber baslangici
public function xeberler(){
   $cavab=$this->dtbs->cedvel('xeberler');
      $data['bilgi']=$cavab;
      $this->load->view('back/xeberler/anasehife',$data);

}
public function xeberelave(){
  $this->load->view('back/xeberler/add/anasehife');
}
public function xeberelaveetme(){
  $title=$this->input->post('basliq');
  $tool=permalink($title);
  $katID=$this->input->post('katID');

  if ($katID==6) {
    $kateqoriya="medeniyyet";
     }elseif ($katID==7) {
      $kateqoriya="siyasi";
       }elseif ($katID==8) {
        $kateqoriya="iqtisadi";
       }
       elseif ($katID==9) {
        $kateqoriya="idman";
       }elseif ($katID==10) {
        $kateqoriya="magazin";
       }elseif ($katID==11) {
        $kateqoriya="maraqli";
       }
       $kattool=permalink($kateqoriya);
       $tarix=$this->input->post('tarix');
       $xeber=$this->input->post('xeber');
       $serh=$this->input->post('serh');
       $sondeqiqe=$this->input->post('sondeqiqe');
       $tag=$this->input->post('tag');
       $hit=0;
       $status=1;



  $config['upload_path']= FCPATH.'assets/front/images/xeber';
  $config['allowed_types']= 'gif|jpg|jpeg|png';
  $config['encrypt_name']= TRUE;
  $this->load->library('upload',$config);
  if ($this->upload->do_upload('resim')) {
    $resim =$this->upload->data();
    $resimyolu =$resim['file_name'];
    $resimqeyd ='assets/front/images/xeber/'.$resimyolu.'';
    $resimtmb ='assets/front/images/xeber/tmb/'.$resimyolu.'';
    $resimmini ='assets/front/images/xeber/mini/'.$resimyolu.'';
    $config['image_library'] ='gd2';
    $config['source_image'] ='assets/front/images/xeber/'.$resimyolu.'';
    $config['new_image'] ='assets/front/images/xeber/tmb/'.$resimyolu.'';
    $config['create_thumb'] =false;
    $config['maintain_ratio'] =false;
    $config['quality'] ='60%';
    $config['width'] =409;
    $config['height'] =260;
    $this->load->library('image_lib',$config);
    $this->image_lib->initialize($config);
    $this->image_lib->resize();
    $this->image_lib->clear();
    //tmb papkasinin bitisi
    //mini papkasinin baslangici
    $config1['image_library'] ='gd2';
    $config1['source_image'] ='assets/front/images/xeber/'.$resimyolu.'';
    $config1['new_image'] ='assets/front/images/xeber/mini/'.$resimyolu.'';
    $config1['create_thumb'] =false;
    $config1['maintain_ratio'] =false;
    $config1['quality'] ='60%';
    $config1['width'] =94;
    $config1['height'] =73;
    $this->load->library('image_lib',$config1);
    $this->image_lib->initialize($config1);
    $this->image_lib->resize();
    $this->image_lib->clear();

    $data=array('resim'=>$resimqeyd,'tmb'=>$resimtmb,'mini'=>$resimmini,'title'=>$title,
                 'tool'=>$tool,'katID'=>$katID,'kateqoriya'=>$kateqoriya,
                 'kattool'=>$kattool,'tarix'=>$tarix,'xeber'=>$xeber,'yorum'=>$serh,
                 'sondeqiqe'=>$sondeqiqe,'tag'=>$tag,'status'=>$status,'hit'=>$hit);
    $cavab=$this->dtbs->elave('xeberler',$data);
   if ($cavab) {
 $this->session->set_flashdata('veziyyet','<div class="alert alert-success"><h4> Xeber Elave etdiniz...</h4></div>');
        redirect('admin/xeberler');
          }else{
            $this->session->set_flashdata('veziyyet','<div class="alert alert-danger"><h4>Sehv!!!Elave edilmedi</h4></div>');
        redirect('admin/xeberler');

          }


  }else{
    //sekil elave edilmediyinde xeta vereceyi qisim
    $this->session->set_flashdata('veziyyet','<div class="alert alert-danger"><h4>Sehv!!!Sekil Elave edilmedi</h4></div>');
        redirect('admin/xeberler');
  }



}
public function xeberset(){
  $id=$this->input->post('id');
  $status=($this->input->post('status')=="true") ? 1 : 0 ;
  $this->db->where('id',$id)->update('xeberler',array('status'=>$status));
}
public function xeberdeyis($id){

    $cavab=$this->dtbs->cek($id,'xeberler');
     $data['bilgi']=$cavab;
    $this->load->view('back/xeberler/edit/anasehife',$data);

}
public function xeberguncelle(){
  $id=$this->input->post('id');
  $status=$this->input->post('status');
  $title=$this->input->post('basliq');
  $tool=permalink($title);
  $katID=$this->input->post('katID');

  if ($katID==6) {
    $kateqoriya="medeniyyet";
     }elseif ($katID==7) {
      $kateqoriya="siyasi";
       }elseif ($katID==8) {
        $kateqoriya="iqtisadi";
       }
       elseif ($katID==9) {
        $kateqoriya="idman";
       }elseif ($katID==9) {
        $kateqoriya="maqazin";
       }elseif ($katID==10) {
        $kateqoriya="sagliq";
       }
       $kattool=permalink($kateqoriya);
       $tarix=$this->input->post('tarix');
       $xeber=$this->input->post('xeber');
       $serh=$this->input->post('serh');
       $sondeqiqe=$this->input->post('sondeqiqe');
       $tag=$this->input->post('tag');
       



  $config['upload_path']= FCPATH.'assets/front/images/xeber';
  $config['allowed_types']= 'gif|jpg|jpeg|png';
  $config['encrypt_name']= TRUE;
  $this->load->library('upload',$config);
  if ($this->upload->do_upload('resim')) {
    $resim =$this->upload->data();
    $resimyolu =$resim['file_name'];
    $resimqeyd ='assets/front/images/xeber/'.$resimyolu.'';
    $resimtmb ='assets/front/images/xeber/tmb/'.$resimyolu.'';
    $resimmini ='assets/front/images/xeber/mini/'.$resimyolu.'';
    $config['image_library'] ='gd2';
    $config['source_image'] ='assets/front/images/xeber/'.$resimyolu.'';
    $config['new_image'] ='assets/front/images/xeber/tmb/'.$resimyolu.'';
    $config['create_thumb'] =false;
    $config['maintain_ratio'] =false;
    $config['quality'] ='60%';
    $config['width'] =409;
    $config['height'] =260;
    $this->load->library('image_lib',$config);
    $this->image_lib->initialize($config);
    $this->image_lib->resize();
    $this->image_lib->clear();
    //tmb papkasinin bitisi
    //mini papkasinin baslangici
    $config1['image_library'] ='gd2';
    $config1['source_image'] ='assets/front/images/xeber/'.$resimyolu.'';
    $config1['new_image'] ='assets/front/images/xeber/mini/'.$resimyolu.'';
    $config1['create_thumb'] =false;
    $config1['maintain_ratio'] =false;
    $config1['quality'] ='60%';
    $config1['width'] =94;
    $config1['height'] =73;
    $this->load->library('image_lib',$config1);
    $this->image_lib->initialize($config1);
    $this->image_lib->resize();
    $this->image_lib->clear();



    $hsil=xeberresim($id);
    $htsil=xebertmb($id);
    $hmsil=xebermini($id);
    unlink($hsil);
    unlink($htsil);
    unlink($hmsil);


    $data=array('resim'=>$resimqeyd,'tmb'=>$resimtmb,'mini'=>$resimmini,'title'=>$title,
                 'tool'=>$tool,'katID'=>$katID,'kateqoriya'=>$kateqoriya,
                 'kattool'=>$kattool,'tarix'=>$tarix,'xeber'=>$xeber,'yorum'=>$serh,
                 'sondeqiqe'=>$sondeqiqe,'tag'=>$tag,'status'=>$status);
    $cavab=$this->dtbs->guncelle($data,$id,'id','xeberler');
   if ($cavab) {
 $this->session->set_flashdata('veziyyet','<div class="alert alert-success"><h4> Xeber deyisdirdiniz...</h4></div>');
        redirect('admin/xeberler');
          }else{
            $this->session->set_flashdata('veziyyet','<div class="alert alert-danger"><h4>Sehv!!!deyisidirilmedi</h4></div>');
        redirect('admin/xeberler');

          }


  }else{
    //sekil elave edilmediyinde xeta vereceyi qisim
     $data=array('title'=>$title,
                 'tool'=>$tool,'katID'=>$katID,'kateqoriya'=>$kateqoriya,
                 'kattool'=>$kattool,'tarix'=>$tarix,'xeber'=>$xeber,'yorum'=>$serh,
                 'sondeqiqe'=>$sondeqiqe,'tag'=>$tag,'status'=>$status);
    $cavab=$this->dtbs->guncelle($data,$id,'id','xeberler');
   if ($cavab) {
 $this->session->set_flashdata('veziyyet','<div class="alert alert-success"><h4> Xeber deyisdirdiniz...</h4></div>');
        redirect('admin/xeberler');
          }else{
            $this->session->set_flashdata('veziyyet','<div class="alert alert-danger"><h4>Sehv!!!deyisidirilmedi</h4></div>');
        redirect('admin/xeberler');

          }




}

}

public function xebersil($id,$where,$from){
   $hsil=xeberresim($id);
    $htsil=xebertmb($id);
    $hmsil=xebermini($id);
    unlink($hsil);
    unlink($htsil);
    unlink($hmsil);


    $cavab=$this->dtbs->sil($id,$where,$from);
  if ($cavab) {
        $this->session->set_flashdata('veziyyet','<div class="alert alert-success"><h4> Silindi...</h4></div>');
        redirect('admin/xeberler');


   }else{
        $this->session->set_flashdata('veziyyet','<div class="alert alert-danger"><h4>Silinmedi!!!</h4></div>');
        redirect('admin/xeberler');
}


}
//xeberler bitisi
//redaktor baslangici
public function redaktor(){
  $cavab=$this->dtbs->cedvel('redaktor');
  $data['bilgi']=$cavab;
  $this->load->view('back/redaktor/anasehife',$data);
}
public function redaktorelave(){
  $this->load->view('back/redaktor/add/anasehife');
}
public function redaktorelaveetme(){


   $config['upload_path']= FCPATH.'assets/front/images/redaktor';
  $config['allowed_types']= 'gif|jpg|jpeg|png';
  $config['encrypt_name']= TRUE;
  $this->load->library('upload',$config);
  if ($this->upload->do_upload('resim')) {
    $resim =$this->upload->data();
    $resimyolu =$resim['file_name'];
    $resimqeyd ='assets/front/images/redaktor/'.$resimyolu.'';
    $resimmini ='assets/front/images/redaktor/mini/'.$resimyolu.'';
    $config['image_library'] ='gd2';
    $config['source_image'] ='assets/front/images/redaktor/'.$resimyolu.'';
    $config['new_image'] ='assets/front/images/redaktor/mini/'.$resimyolu.'';
    $config['create_thumb'] =false;
    $config['maintain_ratio'] =false;
    $config['quality'] ='60%';
    $config['width'] =94;
    $config['height'] =73;
    $this->load->library('image_lib',$config);
    $this->image_lib->initialize($config);
    $this->image_lib->resize();
    $this->image_lib->clear();

    $data=array('resim'=>$resimqeyd,'mini'=>$resimmini,'adi'=>$adi=$this->input->post('adi'),'status'=>$status=1);
    $cavab=$this->dtbs->elave('redaktor',$data);

}if ($cavab) {
 $this->session->set_flashdata('veziyyet','<div class="alert alert-success"><h4>  Elave etdiniz...</h4></div>');
        redirect('admin/redaktor');
          }else{
            $this->session->set_flashdata('veziyyet','<div class="alert alert-danger"><h4>Sehv!!!Elave edilmedi</h4></div>');
        redirect('admin/redaktor');

          }
          }
   public function redaktorset(){
  $id=$this->input->post('id');
  $status=($this->input->post('status')=="true") ? 1 : 0 ;
  $this->db->where('id',$id)->update('redaktor',array('status'=>$status));
}
public function redaktordeyis($id){
  $cavab=$this->dtbs->cek($id,'redaktor');
  $data['bilgi']=$cavab;
  $this->load->view('back/redaktor/edit/anasehife',$data);

}
public function redaktorguncelle(){
  $config['upload_path']= FCPATH.'assets/front/images/redaktor';
  $config['allowed_types']= 'gif|jpg|jpeg|png';
  $config['encrypt_name']= TRUE;
  $this->load->library('upload',$config);
  if ($this->upload->do_upload('resim')) {
    $resim =$this->upload->data();
    $resimyolu =$resim['file_name'];
    $resimqeyd ='assets/front/images/redaktor/'.$resimyolu.'';
    $resimmini ='assets/front/images/redaktor/mini/'.$resimyolu.'';
    $config['image_library'] ='gd2';
    $config['source_image'] ='assets/front/images/redaktor/'.$resimyolu.'';
    $config['new_image'] ='assets/front/images/redaktor/mini/'.$resimyolu.'';
    $config['create_thumb'] =false;
    $config['maintain_ratio'] =false;
    $config['quality'] ='60%';
    $config['width'] =94;
    $config['height'] =73;
    $this->load->library('image_lib',$config);
    $this->image_lib->initialize($config);
    $this->image_lib->resize();
    $this->image_lib->clear();

    $rsil=redaktorresim($id);
    $rmsil=redaktormini($id);
    unlink($rsil);
    unlink($rmsil);

    $data=array('id'=>$id=$this->input->post('id'),
      'resim'=>$resimqeyd,'mini'=>$resimmini,'adi'=>$adi=$this->input->post('adi'),'status'=>$status=$this->input->post('status'));
    $cavab=$this->dtbs->guncelle($data,$id,'id','redaktor');

}if ($cavab) {
 $this->session->set_flashdata('veziyyet','<div class="alert alert-success"><h4> Deyisdirdiniz</h4></div>');
        redirect('admin/redaktor');
          }
          else{
            $this->session->set_flashdata('veziyyet','<div class="alert alert-danger"><h4>Sehv!!!Deyisilmedi</h4></div>');
        redirect('admin/redaktor');

          }
        }

public function redaktorsil($id,$where,$from){
    $rsil=redaktorresim($id);
    $rmsil=redaktormini($id);
    unlink($rsil);
    unlink($rmsil);


    $cavab=$this->dtbs->sil($id,$where,$from);
  if ($cavab) {
        $this->session->set_flashdata('veziyyet','<div class="alert alert-success"><h4> Silindi...</h4></div>');
        redirect('admin/redaktor');


   }else{
        $this->session->set_flashdata('veziyyet','<div class="alert alert-danger"><h4>Silinmedi!!!</h4></div>');
        redirect('admin/redaktor');
}


}
//redaktorlar bitisi 
//kunye baslangici
public function kunye(){
  $cavab=$this->dtbs->cedvel('kunye');
  $data['bilgi']=$cavab;
  $this->load->view('back/kunye/anasehife',$data);
}
public function kunyeelave(){
  $this->load->view('back/kunye/add/anasehife');
}
public function kunyeelaveetme(){
  $data=array(
    'adi'=>$adi=$this->input->post('adi'),
    'vezife'=>$vezife=$this->input->post('vezife'),
    'status'=>$status=1

  );
  $cavab=$this->dtbs->elave('kunye',$data);
  if ($cavab) {
 $this->session->set_flashdata('veziyyet','<div class="alert alert-success"><h4>Elave etdiniz...</h4></div>');
        redirect('admin/kunye');
          }else{
            $this->session->set_flashdata('veziyyet','<div class="alert alert-danger"><h4>Sehv!!!Elave edilmedi</h4></div>');
        redirect('admin/kunye');

          }


}
public function kunyeset(){
  $id=$this->input->post('id');
  $status=($this->input->post('status')=="true") ? 1 : 0 ;
  $this->db->where('id',$id)->update('kunye',array('status'=>$status));

}
public function kunyedeyis($id){
   $cavab=$this->dtbs->cek($id,'kunye');
     $data['bilgi']=$cavab;
  $this->load->view('back/kunye/edit/anasehife',$data);
}
public function kunyeguncelle(){
  $data=array(
    'id'=>$id=$this->input->post('id'),
    'adi'=>$adi=$this->input->post('adi'),
    'vezife'=>$vezife=$this->input->post('vezife'),
    'status'=>$status=$this->input->post('status')
  );
  $cavab=$this->dtbs->guncelle($data,$id,'id','kunye');
  if ($cavab) {
        $this->session->set_flashdata('veziyyet','<div class="alert alert-success"><h4>Kunyeni deyisdirdiniz...</h4></div>');
        redirect('admin/kunye');


   }else{
        $this->session->set_flashdata('veziyyet','<div class="alert alert-danger"><h4> Kunye Deyisdirilmedi!!!</h4></div>');
        redirect('admin/kunye');
       }

}
public function kunyesil($id,$where,$from){
  $cavab=$this->dtbs->sil($id,$where,$from);
  if ($cavab) {
        $this->session->set_flashdata('veziyyet','<div class="alert alert-success"><h4> Silindi...</h4></div>');
        redirect('admin/kunye');


   }else{
        $this->session->set_flashdata('veziyyet','<div class="alert alert-danger"><h4>Silinmedi!!!</h4></div>');
        redirect('admin/kunye');
       }


     

}
//kunye bitisi
//reklam baslangici
public function reklam(){
  $cavab=$this->dtbs->cedvel('reklam');
  $data['bilgi']=$cavab;
  $this->load->view('back/reklam/anasehife',$data);
}
public function reklamelave()
{
  $this->load->view('back/reklam/add/anasehife');
}
public function reklamelaveetme(){


   $config['upload_path']= FCPATH.'assets/front/images/reklam';
  $config['allowed_types']= 'gif|jpg|jpeg|png';
  $config['encrypt_name']= TRUE;
  $this->load->library('upload',$config);
  if ($this->upload->do_upload('sekil')) {
    $sekil =$this->upload->data();
    $sekilyolu =$sekil['file_name'];
    $sekilqeyd ='assets/front/images/reklam/'.$sekilyolu.'';
    $sekiltmb ='assets/front/images/reklam/tmb/'.$sekilyolu.'';
    $config['image_library'] ='gd2';
    $config['source_image'] ='assets/front/images/reklam/'.$sekilyolu.'';
    $config['new_image'] ='assets/front/images/reklam/tmb/'.$sekilyolu.'';
    $config['create_thumb'] =false;
    $config['maintain_ratio'] =false;
    $config['quality'] ='60%';
    $config['width'] =729;
    $config['height'] =90;
    $this->load->library('image_lib',$config);
    $this->image_lib->initialize($config);
    $this->image_lib->resize();
    $this->image_lib->clear();

    $data=array('sekil'=>$sekilqeyd,'tmb'=>$sekiltmb,
      'sirket'=>$sirket=$this->input->post('sirket'),
      'status'=>$status=1,
      'link'=>$link=$this->input->post('link'),
      'baslangic'=>$baslangic=$this->input->post('baslangic'),
      'bitis'=>$bitis=$this->input->post('bitis'));
    $cavab=$this->dtbs->elave('reklam',$data);

}if ($cavab) {
 $this->session->set_flashdata('status','<div class="alert alert-success"><h4>  Elave etdiniz...</h4></div>');
        redirect('admin/reklam');
          }else{
            $this->session->set_flashdata('status','<div class="alert alert-danger"><h4>Sehv!!!Elave edilmedi</h4></div>');
        redirect('admin/reklam');

          }
          }
   public function reklamset(){
  $id=$this->input->post('id');
  $status=($this->input->post('status')=="true") ? 1 : 0 ;
  $this->db->where('id',$id)->update('reklam',array('status'=>$status));
}
public function reklamdeyis($id)
{
  $cavab=$this->dtbs->cek($id,'reklam');
  $data['bilgi']=$cavab;
  $this->load->view('back/reklam/edit/anasehife',$data);
}
public function reklamguncelle(){
  $config['upload_path']= FCPATH.'assets/front/images/reklam';
  $config['allowed_types']= 'gif|jpg|jpeg|png';
  $config['encrypt_name']= TRUE;
  $this->load->library('upload',$config);
  if ($this->upload->do_upload('sekil')) {
    $sekil =$this->upload->data();
    $sekilyolu =$sekil['file_name'];
    $sekilqeyd ='assets/front/images/reklam/'.$sekilyolu.'';
    $sekiltmb ='assets/front/images/reklam/tmb/'.$sekilyolu.'';
    $config['image_library'] ='gd2';
    $config['source_image'] ='assets/front/images/reklam/'.$sekilyolu.'';
    $config['new_image'] ='assets/front/images/reklam/tmb/'.$sekilyolu.'';
    $config['create_thumb'] =false;
    $config['maintain_ratio'] =false;
    $config['quality'] ='60%';
    $config['width'] =729;
    $config['height'] =90;
    $this->load->library('image_lib',$config);
    $this->image_lib->initialize($config);
    $this->image_lib->resize();
    $this->image_lib->clear();
      $rsil=reklamsekil($id);
    $rtsil=reklamtmb($id);
    unlink($rsil);
    unlink($rtsil);

    $data=array('id'=>$id=$this->input->post('id'),
      'sekil'=>$sekilqeyd,'tmb'=>$sekiltmb,'sirket'=>$sirket=$this->input->post('sirket'),'status'=>$status=$this->input->post('status'),
      'baslangic'=>$baslangic=$this->input->post('baslangic'),
      'link'=>$link=$this->input->post('link'),
      'bitis'=>$bitis=$this->input->post('bitis')
    );
    $cavab=$this->dtbs->guncelle($data,$id,'id','reklam');

}if ($cavab) {
 $this->session->set_flashdata('status','<div class="alert alert-success"><h4> Deyisdirdiniz</h4></div>');
        redirect('admin/reklam');
          }
          else{
            $this->session->set_flashdata('status','<div class="alert alert-danger"><h4>Sehv!!!Deyisilmedi</h4></div>');
        redirect('admin/reklam');

          }
        }

  
public function reklamsil($id,$where,$from){
    $rsil=reklamsekil($id);
    $rtsil=reklamtmb($id);
    unlink($rsil);
    unlink($rtsil);

    $cavab=$this->dtbs->sil($id,$where,$from);
  if ($cavab) {
        $this->session->set_flashdata('status','<div class="alert alert-success"><h4> Silindi...</h4></div>');
        redirect('admin/reklam');

   }else{
        $this->session->set_flashdata('status','<div class="alert alert-danger"><h4>Silinmedi!!!</h4></div>');
        redirect('admin/reklam');
}


}
//reklam bitisi
//comment baslangici
public function comment(){
  $cavab=$this->dtbs->cedvel('serh');
  $data['bilgi']=$cavab;
  $this->load->view('back/comment/anasehife',$data);
}
public function commentset(){
  $id=$this->input->post('id');
  $status=($this->input->post('status')=="true") ? 1 : 0 ;
  $this->db->where('id',$id)->update('serh',array('status'=>$status));
}
public function commentdeyis($id){
  $cavab=$this->dtbs->cek($id,'serh');
  $data['bilgi']=$cavab;
  $this->load->view('back/comment/edit/anasehife',$data);
}
public function commentguncelle(){
  $data=array(
'id'=>$id=$this->input->post('id'),
'adi'=>$adi=$this->input->post('adi'),
'status'=>$status=$this->input->post('status'),
'serh'=>$comment=$this->input->post('comment') 

  );
  $cavab=$this->dtbs->guncelle($data,$id,'id','serh');
if ($cavab) {
        $this->session->set_flashdata('status','<div class="alert alert-success"><h4>commenti deyisdirdiniz...</h4></div>');
        redirect('admin/comment');


   }else{
        $this->session->set_flashdata('status','<div class="alert alert-danger"><h4> comment Deyisdirilmedi!!!</h4></div>');
        redirect('admin/comment');
       }

}
public function commentsil($id,$where,$from){
  $cavab=$this->dtbs->sil($id,$where,$from);
  if ($cavab) {
        $this->session->set_flashdata('status','<div class="alert alert-success"><h4> Silindi...</h4></div>');
        redirect('admin/comment');


   }else{
        $this->session->set_flashdata('status','<div class="alert alert-danger"><h4>Silinmedi!!!</h4></div>');
        redirect('admin/comment');
       }

}
public function mesaj(){
  $cavab=$this->dtbs->cedvel('mesaj');
  $data['bilgi']=$cavab;
  $this->load->view('back/mesajlar/anasehife',$data);
}

public function mesajdeyis($id){
  $cavab=$this->dtbs->cek($id,'mesaj');
  $data['bilgi']=$cavab;
  if ($cavab) {
$data['cavab']=$cavab;
$this->load->view('back/mesajlar/edit/anasehife',$data);
$data=array('status'=>1);
$this->dtbs->mesajupdate($cavab['id'],$data);
  }

  $this->load->view('back/mesajlar/edit/anasehife',$data);
}

public function mesajsil($id,$where,$from){
  $cavab=$this->dtbs->sil($id,$where,$from);
  if ($cavab) {
        $this->session->set_flashdata('status','<div class="alert alert-success"><h4> Silindi...</h4></div>');
        redirect('admin/mesaj');


   }else{
        $this->session->set_flashdata('status','<div class="alert alert-danger"><h4>Silinmedi!!!</h4></div>');
        redirect('admin/mesaj');
       }

}
}