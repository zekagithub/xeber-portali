<article class="v-post clearfix article-title-meta-image animation post--content image_post post-no-border post-1897 post type-post status-publish format-standard has-post-thumbnail hentry category-world" data-animate="fadeInUp" itemscope="" itemtype="https://schema.org/Article">
<h1 class="post-head-title">
<a itemprop="url" title="<?php echo $bilgi['title']; ?>" rel="bookmark">
</a>
</h1>
<div class="clearfix"></div>
<div class="post-meta">
<div class="post-meta-date"><i class="fa fa-calendar"></i><?php echo $bilgi['tarix']; ?></div>

</div>
<div class="clearfix"></div>
<div  class="post-img post-img-9">
<div class="post-type"><i class="fa fa-image"></i></div>
<a title="<?php echo $bilgi['title'];?>" rel="bookmark">
<img alt="" width='750' height='354' src='<?php echo base_url(); echo $bilgi['resim']; ?>'>
</a>
</div>
<div class="post-inner">
<?php echo $bilgi['xeber']; ?>
<div class="post-more">

</div>
<div class="clearfix"></div>
</div>
</article>
<?php if ($bilgi['yorum']==1) {?>
<div class="post-title"><h3>Comments</h3></div><div class="clearfix"></div>
<ol class="commentlist clearfix">
<?php $clist=commentlist($bilgi['id']); foreach ($clist as $clist ) {?>

<li class="comment even thread-even depth-1 single-comment" id="li-comment-73">
<div id="comment-73" class="comment-body">
<div class="avatar">
<img alt="" src="http://localhost/magazin/assets/front/images/avatar.png"
srcset="http://localhost/magazin/assets/front/images/avatar.png" class="avatar avatar-70 photo" height="70" width="70">
</div>
<div class="comment-text">
<div class="author clearfix">
<div class="comment-meta">
<span class="comment-author fn"><?php echo $clist['adi']; ?></span>
<div class="date"><a><i class="fa fa-calendar"></i><time><?php echo $clist ['tarix']; ?></time></a></div>
<div class="clearfix"></div>
</div>
</div>
<div class="text">
<p><?php echo $clist['serh']; ?></p>
</div>
</div>
</div>
</li>
<?php } ?>

</ol>
<div class="post-inner">
<div class="post-title"><h3>Şərh Yazın</h3></div><div class="clearfix"></div>
<div class="comment-form">
<form action="<?php echo base_url('anasehife/comment') ?>" method="post" id="commentform">
<div class="form-input">
<input type="text" name="adsoyad" required placeholder="Ad və soyadınız">
</div>
<div class="form-input form-input-last">
<input type="email" name="email" required placeholder="Email Adresiniz">
</div>
<div class="form-input form-textarea">
<textarea id="yorum" name="yorum" required placeholder="Şərhiniz"></textarea>
</div>
<input name="submit" type="submit" id="submit" value="Gonder" class="button-default">
<input type='hidden' name='movzuid' value="<?php echo $bilgi['id']; ?>" />
<input type='hidden' name='movzutool' value="<?php echo $bilgi['tool']; ?>" />
<input type="hidden" name="movzukat" value="<?php echo $bilgi['kateqoriya'] ?>" />
<input type="hidden" name="ip" value=""/>
<div class="clearfix"></div>
</form>
</div>
</div>
<?php } ?>

