<div class="header-follow header-follow-right">
<ul>
<li class="social-facebook"><a class="tooltip-s" href="http://www.facebook.com" target='_blank'><i class="fa fa-facebook"></i></a></li>
<li class="social-twitter"><a class="tooltip-s" href="http://www.twitter.com" target='_blank'><i class="fa fa-twitter"></i></a></li>
<li class="social-instagram"><a class="tooltip-s" href="http://www.intagram.com" target='_blank'><i class="fa fa-instagram"></i></a></li>
<li class="social-google"><a class="tooltip-s" href="http://www.google.com" target='_blank'><i class="fa fa-google-plus"></i></a></li>
</ul>
</div>