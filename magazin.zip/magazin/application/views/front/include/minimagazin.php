
<div class="col-md-12">

<div class="box-border">
<div class="post-title post-title-news">
<h3><a>MAGAZİN XEBERLERİ</a></h3></div>
<div class="clearfix"></div>

<div class="box-news box-news-1 box-news-sidebar">
<div class="row">
<ul>
<?php $mkat=10; $mveriler=magazinsoncek($mkat);foreach ($mveriler as $mveri ) {?>

<li class="col-md-6 col-sm-6 col-xs-6 col-mo-100">
<div class="box-news-big">
<div class="box-news-img">
<img alt='<?php echo $mveri['title']; ?>' width='409' height='260' src='<?php echo base_url();echo $mveri['tmb']; ?>'>
<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/magazindetal/');echo $mveri['tool']; ?> " rel="bookmark"></a></div>
</div>

<div class="box-news-content">
<div class="box-news-title">
	<a href="<?php echo base_url('anasehife/magazindetal/');echo $mveri['tool']; ?> "  rel="bookmark"><?php echo $mveri['title']; ?></a>
</div>
<div class="box-news-meta">
<time class="box-news-meta-date"><i class="fa fa-calendar"></i><?php echo $mveri['tarix']; ?></time>
<a class="box-news-meta-comment" href="#"><i class="fa fa-comments-o"></i>0</a>
<div class="box-news-meta-view"><i class="fa fa-eye"></i><?php echo $mveri['hit']; ?></div>
</div>
<div class="box-news-desc">
<?php echo  word_limiter($mveri ['xeber'],25); ?>
</div>
<div class="post-more"><a href="<?php echo base_url('anasehife/magazindetal/');echo $mveri['tool']; ?> "  class="button-default medium" rel="bookmark">Davami</a></div>
</div>
<div class="clearfix"></div>
</div>
</li>
<?php } ?>
<?php $mkat=10; $veriler=magazincek($mkat);foreach ($veriler as $veri ) {?>

<li class="col-md-6 col-sm-6 col-xs-6 col-mo-100">
<div class="box-news-small">
<div class="box-news-img">
<img alt='<?php echo $veri['title']; ?>' width='94' height='73' src='<?php echo base_url();echo $veri['tmb']; ?>'>
<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/magazindetal/');echo $veri['tool']; ?> " rel="bookmark"></a></div>
</div>
<div class="box-news-content">
<div class="box-news-title"><a href="<?php echo base_url('anasehife/magazindetal/');echo $veri['tool']; ?> "  rel="bookmark"><?php echo $veri['title']; ?></a></div>
<div class="box-news-meta">
<time class="box-news-meta-date"><i class="fa fa-calendar"></i><?php echo $veri['tarix']; ?></time>
<a class="box-news-meta-comment" href="#"><i class="fa fa-comments-o"></i>0</a>
<div class="box-news-meta-view"><i class="fa fa-eye"></i><?php echo $veri['hit']; ?></div>
</div>
</div>
<div class="clearfix"></div>
</div>
</li>
<?php } ?>
</ul>
</div>
</div>
<div class="clearfix"></div>
</div>
</div>