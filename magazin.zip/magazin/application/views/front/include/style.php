<link rel="shortcut icon" href="<?php echo base_url('assets/front/'); ?>images/favicon.png" type="image/x-icon">
<link rel='dns-prefetch' href='http://fonts.googleapis.com/' />
<link rel='stylesheet' href='<?php echo base_url('assets/front/'); ?>css/styles33a6.css?ver=4.9' type='text/css' media='all' />
<link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Lato%3A400%2C700&amp;subset=latin%2Clatin-ext' type='text/css' media='all' />
<link rel='stylesheet' href='<?php echo base_url('assets/front/'); ?>css/base4a41.css?ver=4.8.2' type='text/css' media='all' />
<link rel='stylesheet' href='<?php echo base_url('assets/front/'); ?>css/bootstrap.min4a41.css?ver=4.8.2' type='text/css' media='all' />
<link rel='stylesheet' href='<?php echo base_url('assets/front/'); ?>css/prettyPhoto4a41.css?ver=4.8.2' type='text/css' media='all' />
<link rel='stylesheet' href='<?php echo base_url('assets/front/'); ?>css/font-awesome/css/font-awesome.min4a41.css?ver=4.8.2' type='text/css' media='all' />
<link rel='stylesheet' href='<?php echo base_url('assets/front/'); ?>css/EnFonto/style4a41.css?ver=4.8.2' type='text/css' media='all' />
<link rel='stylesheet' href='<?php echo base_url('assets/front/'); ?>css/animate-custom4a41.css?ver=4.8.2' type='text/css' media='all' />
<link rel='stylesheet' href='<?php echo base_url('assets/front/'); ?>css/style.css' type='text/css' media='all' />
<link rel='stylesheet' href='<?php echo base_url('assets/front/'); ?>css/main4a41.css?ver=4.8.2' type='text/css' media='all' />
<link rel='stylesheet' href='<?php echo base_url('assets/front/'); ?>css/responsive4a41.css?ver=4.8.2' type='text/css' media='all' />
<link rel='stylesheet' href='<?php echo base_url('assets/front/'); ?>css/dark4a41.css?ver=4.8.2' type='text/css' media='all' />
<link rel='stylesheet' href='<?php echo base_url('assets/front/'); ?>css/skins/skins4a41.css?ver=4.8.2' type='text/css' media='all' />
<link rel='stylesheet' href='<?php echo base_url('assets/front/'); ?>css/custom4a41.css?ver=4.8.2' type='text/css' media='all' />
<style type='text/css'>
@media only screen and (max-width: 479px) {
.bottom-header.fixed-nav {
position: static !important;
}
}

#sections-id-3 .box-slideshow {
margin-bottom: 30px
}
</style>