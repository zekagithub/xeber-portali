<nav class="navigation navigation-left" rel="navigation_left">
<div class="header-menu">
<ul id="menu-top-header-main" class="">
<li class="menu-item menu-item-type-post_type"><a href="<?php echo base_url(); ?>" class="">Anasehife</a></li>
<li class="menu-item menu-item-type-post_type"><a href="<?php echo base_url('anasehife/haqqimizda'); ?>" class="">Haqqimizda</a></li>
<li class="menu-item menu-item-type-post_type"><a href="<?php echo base_url('anasehife/elaqe'); ?>" class="">Elaqe</a></li>
</ul>
</div>
</nav>