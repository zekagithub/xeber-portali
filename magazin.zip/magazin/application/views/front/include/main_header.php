<div class="main-header">
<div class="container">
<div class="logo">
<a class="logo-img" href="<?php echo base_url(); ?>" title="WorldPlus">
<img class="default_logo" alt="news" src="<?php echo base_url(); ?>assets/front/images/news.png">
</a>
</div>
<div style="margin-bottom: 15px;" class="worldplus-ad worldplus-ad-header-1">
<?php $reklamlar=reklamcek();$btt=date('Y-m-d');if ($reklamlar['status']==1 && $reklamlar['bitis']>$btt) {?>
	<a href="http://<?php echo $reklamlar['link']; ?>" target=_blank><img alt="<?php echo $reklamlar['sirket']; ?>" title="<?php echo  $reklamlar['sirket']; ?>" src="<?php echo base_url();echo $reklamlar['tmb']; ?>"></a></div>
<div class="worldplus-ad-clearfix clearfix">
	<?php }else{ ?>
	<a href="#"><img alt="" title="bos reklam" src="<?php echo base_url(); ?>assets/front/images/reklam/bos/reklam.jpg"></a></div>
<div class="worldplus-ad-clearfix clearfix">
	<?php } ?>
</div>
</div>
</div>