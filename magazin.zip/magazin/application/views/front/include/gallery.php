<div class="col-md-12">	<div class="box-border">
<div class="box-slideshow box-slideshow-full slide-show-full slideshow-style-10">
<ul>
	<?php $galleryler=gallery();foreach ($galleryler as $gallery) {?>
	
<li class="slider-item">
<div class="box-slideshow-main box-slideshow-bigger">
<div class="box-slideshow-img">
<img alt='<?php echo $gallery['title']; ?>' width='1140' height='500' src='<?php echo base_url();echo $gallery['resim'];  ?>'>
</div>
<div class="slideshow-overlay"></div>
<div class="box-slideshow-content">
<div class="box-slideshow-outer">
<div class="box-slideshow-inner">
	<?php if ($gallery['kateqoriya']=="siyasi") {?>
<a class="box-news-overlay-3" href="<?php echo base_url('anasehife/siyasetdetal/');echo $gallery['tool']; ?> " title="<?php echo $gallery['title']; ?>" rel="bookmark"></a>
<?php }elseif ($gallery['kateqoriya']=="ekonomi") {?>
<a class="box-news-overlay-3" href="<?php echo base_url('anasehife/ekonomidetal/');echo $gallery['tool']; ?> " title="<?php echo $gallery['title']; ?>" rel="bookmark"></a>
<?php }elseif ($gallery['kateqoriya']=="medeniyyet") {?>
<a class="box-news-overlay-3" href="<?php echo base_url('anasehife/medeniyyetdetal/');echo $gallery['tool']; ?> " title="<?php echo $gallery['title']; ?>" rel="bookmark"></a>
<?php }elseif ($gallery['kateqoriya']=="magazin") {?>
<a class="box-news-overlay-3" href="<?php echo base_url('anasehife/magazindetal/');echo $gallery['tool']; ?> " title="<?php echo $gallery['title']; ?>" rel="bookmark"></a>
<?php }elseif ($gallery['kateqoriya']=="idman") {?>
<a class="box-news-overlay-3" href="<?php echo base_url('anasehife/idmandetal/');echo $gallery['tool']; ?> " title="<?php echo $gallery['title']; ?>" rel="bookmark"></a>
<?php }elseif ($gallery['kateqoriya']=="maraqli") {?>
<a class="box-news-overlay-3" href="<?php echo base_url('anasehife/maraqlidetal/');echo $gallery['tool']; ?> " title="<?php echo $gallery['title']; ?>" rel="bookmark"></a>
<?php } ?>
<span class="slide-category">
<?php if ($gallery['kateqoriya']=="siyasi") {?>

<a href="<?php echo base_url('anasehife/siyasetdetal/');echo $gallery['tool']; ?>" title="<?php echo $gallery['title']; ?>"><?php echo $gallery['kateqoriya']; ?></a>
<?php }elseif ($gallery['kateqoriya']=="ekonomi") {?>
<a href="<?php echo base_url('anasehife/ekonomidetal/');echo $gallery['tool']; ?>" title="<?php echo $gallery['title']; ?>"><?php echo $gallery['kateqoriya']; ?></a>
<?php }elseif ($gallery['kateqoriya']=="medeniyyet") {?>
<a href="<?php echo base_url('anasehife/medeniyyetdetal/');echo $gallery['tool']; ?>" title="<?php echo $gallery['title']; ?>"><?php echo $gallery['kateqoriya']; ?></a>
<?php }elseif ($gallery['kateqoriya']=="magazin") {?>
	<a href="<?php echo base_url('anasehife/magazindetal/');echo $gallery['tool']; ?>" title="<?php echo $gallery['title']; ?>"><?php echo $gallery['kateqoriya']; ?></a>
	<?php }elseif ($gallery['kateqoriya']=="idman") {?>
	<a href="<?php echo base_url('anasehife/idmandetal/');echo $gallery['tool']; ?>" title="<?php echo $gallery['title']; ?>"><?php echo $gallery['kateqoriya']; ?></a>
	<?php }elseif ($gallery['kateqoriya']=="maraqli") {?>
		<a href="<?php echo base_url('anasehife/maraqlidetal/');echo $gallery['tool']; ?>" title="<?php echo $gallery['title']; ?>"><?php echo $gallery['kateqoriya']; ?></a>
		<?php } ?>
</span>
<span class="slide-date"><i class="fa fa-calendar"><?php echo $gallery['tarix']; ?></i></span>
<div class="clearfix"></div>
<a href="# ?>" title="<?php echo $gallery['title']; ?>" rel="bookmark"></a>
</div>
</div>
</div>
</div>
</li>
<?php } ?>
</ul>
</div>
<div class="clearfix"></div>
</div>
</div>
