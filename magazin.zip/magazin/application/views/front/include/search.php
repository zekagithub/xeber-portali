<div id="search-3" class="widget widget_search">
<div class="widget-title">
<h3>Xeber axtar</h3></div>
<div class="clearfix"></div>
<form role="search" method="get" class="search-form" action="#">
<label>
<span class="screen-reader-text">Axtar:</span>
<input type="search" class="search-field" placeholder="Xeber axtar &hellip;" value="" name="s" />
</label>
<input type="submit" class="search-submit" value="Axtar" />
</form>
</div>