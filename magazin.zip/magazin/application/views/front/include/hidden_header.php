<div class="hidden-header">
<div class="bottom-header main-block bottom-header-2">
<div class="container">
<nav class="navigation" rel="navigation_main">
<div class="header-menu">
<ul id="menu-header" class="">
<li class="menu-item menu-item-type-custom"><a href="<?php echo base_url(); ?>"><i class="fa fa-home"></i> ANA SeHIFE</a></li>
</li>
<li class="menu-item menu-item-type-custom"><a href="<?php echo base_url('anasehife/siyaset'); ?>"><i class="fa fa-flag"></i> SİYASET </a></li>
<li class="menu-item menu-item-type-custom"><a href="<?php echo base_url('anasehife/ekonomi'); ?>"><i class="fa fa-money"></i>EKONOMİ </a></li>
<li class="menu-item menu-item-type-custom"><a href="<?php echo base_url('anasehife/medeniyyet'); ?>"><i class="fa fa-university"></i>MEDENIYYET</a></li>
<li class="menu-item menu-item-type-custom"><a href="<?php echo base_url('anasehife/magazin'); ?>"><i class="fa fa-camera"></i>MAGAZİN </a></li>
<li class="menu-item menu-item-type-custom"><a href="<?php echo base_url('anasehife/idman'); ?>"><i class="fa fa-trophy"></i>IDMAN</a></li>
<li class="menu-item menu-item-type-custom"><a href="<?php echo base_url('anasehife/maraqli'); ?>"><i class="fa fa-book"></i>MARAQLI</a></li>
</div>
</nav>
<nav class="navigation_main navigation_mobile navigation_mobile_main">
<div class="navigation_mobile_click">Baxın...</div>
<ul></ul>
</nav>
</div>
</div>
<div class="clearfix"></div>
</div>