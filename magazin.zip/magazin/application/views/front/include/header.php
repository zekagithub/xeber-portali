<header id="header" class="header-1">
<div class="top-header main-block">
<div class="container">
<?php $this->load->view('front/include/headersosiyalmenu'); ?>
<?php $this->load->view('front/include/navleft'); ?>
<?php $this->load->view('front/include/navmobile'); ?>
</div>
</div>
<?php $this->load->view('front/include/main_header'); ?>
<?php $this->load->view('front/include/hidden_header'); ?>
<?php $this->load->view('front/include/b_news'); ?>
</header>