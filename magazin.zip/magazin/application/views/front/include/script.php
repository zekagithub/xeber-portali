
<script type='text/javascript' src='<?php echo base_url('assets/front/'); ?>js/jquery/jqueryb8ff.js?ver=1.12.4'></script>
<script type='text/javascript' src='<?php echo base_url('assets/front/'); ?>js/scripts8a54.js?ver=1.0.0'></script>
<script type='text/javascript' src='<?php echo base_url('assets/front/'); ?>js/custom8a54.js?ver=1.0.0'></script>
<script type='text/javascript' src='<?php echo base_url('assets/front/'); ?>js/custom.js?ver=1.0.0'></script>
