<nav class="navigation_left navigation_mobile navigation_mobile_main">
<div class="navigation_mobile_click">Baxin...</div>
<ul></ul>
</nav>