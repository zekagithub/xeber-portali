<div class="breaking-news main-block breaking-news-3">
<div class="container">
<div class="breaking-news-all">
<div class="breaking-news-title">
<h3 class="title">Son Deqiqe</h3>
</div>
<div class="breaking-news-content">
<ul>
	<?php $sd=2;$veriler=sondeqiqe($sd);foreach ($veriler as $veri) {?>

	<?php if ($veri['kateqoriya']=="siyasi") {?>
<li><a href="<?php echo base_url('anasehife/siyasetdetal/');$veri['tool'];echo $veri['title']; ?>"><?php echo $veri['title']; ?></a></li>
<?php }elseif ($veri['kateqoriya']=="ekonomi") {?>
<li><a href="<?php echo base_url('anasehife/ekonomidetal/');$veri['tool'];echo $veri['title']; ?>"><?php echo $veri['title']; ?></a></li>
<?php }elseif ($veri['kateqoriya']=="medeniyyet") {?>
	<li><a href="<?php echo base_url('anasehife/medeniyyyetdetal/');$veri['tool'];echo $veri['title']; ?>"><?php echo $veri['title']; ?></a></li>
<?php }elseif ($veri['kateqoriya']=="magazin") {?>
<li><a href="<?php echo base_url('anasehife/magazindetal/');$veri['tool'];echo $veri['title']; ?>"><?php echo $veri['title']; ?></a></li>
<?php }elseif ($veri['kateqoriya']=="idman") {?>
<li><a href="<?php echo base_url('anasehife/idmandetal/');$veri['tool'];echo $veri['title']; ?>"><?php echo $veri['title']; ?></a></li>
<?php }elseif ($veri['kateqoriya']=="maraqli") {?>
	<li><a href="<?php echo base_url('anasehife/maraqlidetal/');$veri['tool'];echo $veri['title']; ?>"><?php echo $veri['title']; ?></a></li>
	<?php } ?>
<?php } ?>


</ul>
<div class="clear"></div>
</div>
</div>
</div>
</div>