<div class="col-md-12">
<div class="scroll-news scroll-posts-half scroll-news-new scroll-arrow-top">
<div class="post-title post-title-news">
<h3>SON DƏQİQƏ XƏBƏRLƏRİ</h3></div>
<div class="clearfix"></div>
<div class="row">
<div class="head-slide scroll-posts head-slide-show">
<ul>
<li class='slider-item'>
	<?php $sd=2; $veriler=sondeqiqe1($sd); foreach ($veriler as $veri) {?>
	
<article class="slide-item col-xs-4 col-md-4">
<div class="slide-content">
<div class="slide-data">
<div class="slide-data-outer">
<div class="slide-data-inner">
		<?php if ($veri['kateqoriya']=="siyasi") {?>

<a class="slide-link" href="<?php echo base_url('anasehife/siyasetdetal/');echo $veri['tool']; ?><?php $veri['title']; ?>" rel="bookmark"></a>

<?php }elseif ($veri['kateqoriya']=="ekonomi") {?>
<a class="slide-link" href="<?php echo base_url('anasehife/ekonomidetal/');echo $veri['tool']; ?><?php $veri['title']; ?>" rel="bookmark"></a>

<?php }elseif ($veri['kateqoriya']=="medeniyyet") {?>
<a class="slide-link" href="<?php echo base_url('anasehife/medeniyyetdetal/');echo $veri['tool']; ?><?php $veri['title']; ?>" rel="bookmark"></a>

<?php }elseif ($veri['kateqoriya']=="magazin") {?>
<a class="slide-link" href="<?php echo base_url('anasehife/magazindetal/');echo $veri['tool']; ?><?php $veri['title']; ?>" rel="bookmark"></a>

<?php }elseif ($veri['kateqoriya']=="idman") {?> 
<a class="slide-link" href="<?php echo base_url('anasehife/idmandetal/');echo $veri['tool']; ?><?php $veri['title']; ?>" rel="bookmark"></a>
<?php }elseif ($veri['kateqoriya']=="maraqli") {?>
<a class="slide-link" href="<?php echo base_url('anasehife/maraqlidetal/');echo $veri['tool']; ?><?php $veri['title']; ?>" rel="bookmark"></a>
<?php } ?>
<span class="slide-category">
	
<a href=""><?php echo $veri['kateqoriya']; ?></a>
</span>
<span class="slide-date"><i class='fa fa-calendar'></i><?php echo $veri['tarix']; ?></span>
<span class="slide-review"></span>
</div>
</div>
</div>
<div class="slide-hover"></div>
<div class="slide-image"><span><img alt='<?php echo $veri['title'] ?>' width='263' height='187' src='<?php echo base_url();echo $veri['tmb']; ?>'></span></div>
</div>
<?php if ($veri['kateqoriya']=="siyasi") {?>
<h4 class="slide-title"><a href="<?php echo base_url('anasehife/siyasetdetal/');echo $veri['tool']; ?>" <?php echo $veri['title']; ?> rel="bookmark"><?php echo $veri['title']; ?></a></h4>
<?php }elseif ($veri['kateqoriya']=="ekonomi") {?>
<h4 class="slide-title"><a href="<?php echo base_url('anasehife/ekonomidetal/');echo $veri['tool']; ?>" <?php echo $veri['title']; ?> rel="bookmark"><?php echo $veri['title']; ?></a></h4>
<?php} elseif ($veri['kateqoriya']=="medeniyyet") {?>
<h4 class="slide-title"><a href="<?php echo base_url('anasehife/medeniyyetdetal/');echo $veri['tool']; ?>" <?php echo $veri['title']; ?> rel="bookmark"><?php echo $veri['title']; ?></a></h4>
<?php }elseif ($veri['kateqoriya']=="magazin") {?>
	<h4 class="slide-title"><a href="<?php echo base_url('anasehife/magazindetal/');echo $veri['tool']; ?>" <?php echo $veri['title']; ?> rel="bookmark"><?php echo $veri['title']; ?></a></h4>
	<?php }elseif ($veri['kateqoriya']=="idman") {?>
<h4 class="slide-title"><a href="<?php echo base_url('anasehife/idmandetal/');echo $veri['tool']; ?>" <?php echo $veri['title']; ?> rel="bookmark"><?php echo $veri['title']; ?></a></h4>
<?php } elseif ($veri['kateqoriya']=="maraqli") {?>
<h4 class="slide-title"><a href="<?php echo base_url('anasehife/maraqlidetal/');echo $veri['tool']; ?>" <?php echo $veri['title']; ?> rel="bookmark"><?php echo $veri['title']; ?></a></h4>
<?php } ?>

</article>
<?php } ?>

</li>

<li class='slider-item'>
	<?php $sdi=2;$soncek=sondeqiqe2($sdi);foreach ($soncek as $son) {?>
	
<article class="slide-item col-xs-4 col-md-4">
<div class="slide-content">
<div class="slide-data">
<div class="slide-data-outer">
<div class="slide-data-inner">
	<?php if ($son['kateqoriya']=="siyasi") {?>
<a class="slide-link" href="<?php echo base_url('anasehife/siyasetdetal/');echo $son['tool'];echo $son['title']; ?>" rel="bookmark"></a>
<?php }elseif ($son['kateqoriya']=="ekonomi") {?>
<a class="slide-link" href="<?php echo base_url('anasehife/ekonomidetal/');echo $son['tool'];echo $son['title']; ?>" rel="bookmark"></a>
<?php }elseif ($son['kateqoriya']=="medeniyyet") {?>
<a class="slide-link" href="<?php echo base_url('anasehife/medeniyyetdetal/');echo $son['tool'];echo $son['title']; ?>" rel="bookmark"></a>
<?php }elseif ($son['kateqoriya']=="magazin") {?>
<a class="slide-link" href="<?php echo base_url('anasehife/magazindetal/');echo $son['tool'];echo $son['title']; ?>" rel="bookmark"></a>
<?php }elseif ($son['kateqoriya']=="idman") {?>
<a class="slide-link" href="<?php echo base_url('anasehife/idmandetal/');echo $son['tool'];echo $son['title']; ?>" rel="bookmark"></a>
<?php }elseif ($son['kateqoriya']=="maraqli") {?>
<a class="slide-link" href="<?php echo base_url('anasehife/maraqlidetal/');echo $son['tool'];echo $son['title']; ?>" rel="bookmark"></a>
<?php } ?>

<span class="slide-category">
<a href="#" title=""><?php echo $son['kateqoriya']; ?></a>
</span>
<span class="slide-date"><i class='fa fa-calendar'></i><?php echo $son['tarix']; ?></span>
<span class="slide-review"></span>
</div>
</div>
</div>
<div class="slide-hover"></div>
<div class="slide-image"><span><img alt='<?php echo $son['title']; ?>' width='263' height='187' src='<?php echo base_url();echo $son['tmb']; ?>'></span></div>
</div>
<?php if ($son['kateqoriya']=="siyasi") {?>
<h4 class="slide-title"><a href="<?php echo base_url('anasehife/siyasetdetal/');echo $son['tool'];echo $son['title']; ?>" rel="bookmark"><?php echo $son['title']; ?></a></h4>
<?php }elseif ($son['kateqoriya']=="ekonomi") {?>
<h4 class="slide-title"><a href="<?php echo base_url('anasehife/ekonomidetal/');echo $son['tool'];echo $son['title']; ?>" rel="bookmark"><?php echo $son['title']; ?></a></h4>
<?php }elseif ($son['kateqoriya']=="medeniyyet") {?>
<h4 class="slide-title"><a href="<?php echo base_url('anasehife/medeniyyetdetal/');echo $son['tool'];echo $son['title']; ?>" rel="bookmark"><?php echo $son['title']; ?></a></h4>
<?php }elseif ($son['kateqoriya']=="magazin") {?>
<h4 class="slide-title"><a href="<?php echo base_url('anasehife/magazindetal/');echo $son['tool'];echo $son['title']; ?>" rel="bookmark"><?php echo $son['title']; ?></a></h4>
<?php }elseif ($son['kateqoriya']=="idman") {?>
<h4 class="slide-title"><a href="<?php echo base_url('anasehife/idmandetal/');echo $son['tool'];echo $son['title']; ?>" rel="bookmark"><?php echo $son['title']; ?></a></h4>
<?php }elseif ($son['kateqoriya']=="maraqli") {?>
	<h4 class="slide-title"><a href="<?php echo base_url('anasehife/siyasetdetal/');echo $son['tool'];echo $son['title']; ?>" rel="bookmark"><?php echo $son['title']; ?></a></h4>
<?php } ?>
</article>

<?php } ?>



</li>
</ul>
</div>
</div>
<div class="clearfix"></div>
</div>
</div>
