<div class="col-md-12">
<div class="box-border">
<div class='all-blogs'>
	<?php foreach ($bilgi as $bilgi) {?>
<article class="v-post clearfix article-title-meta-image post-style-6 animation post--content image_post post-no-border post-1912 post type-post status-publish format-standard has-post-thumbnail hentry category-business" data-animate="fadeInUp" itemscope=""
itemtype="http://schema.org/Article">
<div class="post-img post-img-9">
	<?php if ($bilgi['kateqoriya']=="siyasi") {?>
	
<a href="<?php echo base_url('anasehife/siyasetdetal/');echo $bilgi['tool'];?>" rel="bookmark" class='post-img-link'>
<img alt='<?php echo $bilgi['title'];?>' width='280' height='230' src='<?php echo base_url();echo $bilgi['tmb']; ?>'>
</a>
<?php }elseif ($bilgi['kateqoriya']=="ekonomi") {?>
<a href="<?php echo base_url('anasehife/ekonomidetal/');echo $bilgi['tool'];?>" rel="bookmark" class='post-img-link'>
<img alt='<?php echo $bilgi['title'];?>' width='280' height='230' src='<?php echo base_url();echo $bilgi['tmb']; ?>'>
<?php }elseif ($bilgi['kateqoriya']=="medeniyyet") {?>
<a href="<?php echo base_url('anasehife/medeniyyetdetal/');echo $bilgi['tool'];?>" rel="bookmark" class='post-img-link'>
<img alt='<?php echo $bilgi['title'];?>' width='280' height='230' src='<?php echo base_url();echo $bilgi['tmb']; ?>'>
<?php }elseif ($bilgi['kateqoriya']=="magazin") {?>
<a href="<?php echo base_url('anasehife/magazindetal/');echo $bilgi['tool'];?>" rel="bookmark" class='post-img-link'>
<img alt='<?php echo $bilgi['title'];?>' width='280' height='230' src='<?php echo base_url();echo $bilgi['tmb']; ?>'>
<?php }elseif ($bilgi['kateqoriya']=="idman") {?>
<a href="<?php echo base_url('anasehife/idmandetal/');echo $bilgi['tool'];?>" rel="bookmark" class='post-img-link'>
<img alt='<?php echo $bilgi['title'];?>' width='280' height='230' src='<?php echo base_url();echo $bilgi['tmb']; ?>'>
<?php }elseif ($bilgi['kateqoriya']=="maraqli") {?>
	<a href="<?php echo base_url('anasehife/maraqlidetal/');echo $bilgi['tool'];?>" rel="bookmark" class='post-img-link'>
<img alt='<?php echo $bilgi['title'];?>' width='280' height='230' src='<?php echo base_url();echo $bilgi['tmb']; ?>'>
<?php } ?>

</div>
<div class='post-inner-6'>
	<?php if ($bilgi['kateqoriya']=="siyasi") {?>
<h1 class="post-head-title">
<a itemprop="url" href="<?php echo base_url('anasehife/siyasetdetal/');echo $bilgi['tool'];echo $bilgi['title']; ?>" rel="bookmark">
<?php echo $bilgi['title']; ?></a>
</h1>
<?php }elseif ($bilgi['kateqoriya']=="ekonomi") {?>
<h1 class="post-head-title">
<a itemprop="url" href="<?php echo base_url('anasehife/ekonomidetal/');echo $bilgi['tool'];echo $bilgi['title']; ?>" rel="bookmark">
<?php echo $bilgi['title']; ?></a>
</h1>
<?php }elseif ($bilgi['kateqoriya']=="medeniyyet") {?>
<h1 class="post-head-title">
<a itemprop="url" href="<?php echo base_url('anasehife/medeniyyetdetal/');echo $bilgi['tool'];echo $bilgi['title']; ?>" rel="bookmark">
<?php echo $bilgi['title']; ?></a>
</h1>
<?php } elseif ($bilgi['kateqoriya']=="magazin") {?>
<h1 class="post-head-title">
<a itemprop="url" href="<?php echo base_url('anasehife/magazindetal/');echo $bilgi['tool'];echo $bilgi['title']; ?>" rel="bookmark">
<?php echo $bilgi['title']; ?></a>
</h1>
<?php }elseif ($bilgi['kateqoriya']=="idman") {?>
<h1 class="post-head-title">
<a itemprop="url" href="<?php echo base_url('anasehife/idmandetal/');echo $bilgi['tool'];echo $bilgi['title']; ?>" rel="bookmark">
<?php echo $bilgi['title']; ?></a>
</h1>
<?php }elseif ($bilgi['kateqoriya']=="maraqli") {?>
	<h1 class="post-head-title">
<a itemprop="url" href="<?php echo base_url('anasehife/maraqlidetal/');echo $bilgi['tool'];echo $bilgi['title']; ?>" rel="bookmark">
<?php echo $bilgi['title']; ?></a>
</h1>
<?php } ?>



<div class="post-meta">
<div class="post-meta-date"><i class="fa fa-calendar"></i><?php echo  $bilgi['tarix']; ?></div>
<div class="post-meta-category"><i class="fa fa-folder-o"></i><a href="#" rel="category tag"><?php echo $bilgi['kateqoriya']; ?></a></div>
<div class="post-meta-comment"><i class="fa fa-comments-o"></i>0 Comments</div>
</div>
<div class="clearfix"></div>
<div class="post-inner">
<?php echo word_limiter($bilgi['xeber'],35); ?>

<?php if ($bilgi['kateqoriya']=="siyasi") {?>
<div class="post-more"><a class="button-default medium" href="<?php echo base_url('anasehife/siyasetdetal/');echo $bilgi['tool'];echo $bilgi['title']; ?>" rel="bookmark"><i class="fa fa-long-arrow-right"></i>Devamı</a></div>
<?php }elseif ($bilgi['kateqoriya']=="ekonomi") {?>
<div class="post-more"><a class="button-default medium" href="<?php echo base_url('anasehife/ekonomidetal/');echo $bilgi['tool'];echo $bilgi['title']; ?>" rel="bookmark"><i class="fa fa-long-arrow-right"></i>Devamı</a></div>
<?php }elseif ($bilgi['kateqoriya']=="medeniyyet") {?>
	<div class="post-more"><a class="button-default medium" href="<?php echo base_url('anasehife/medeniyyetdetal/');echo $bilgi['tool'];echo $bilgi['title']; ?>" rel="bookmark"><i class="fa fa-long-arrow-right"></i>Devamı</a></div>
	<?php }elseif ($bilgi['kateqoriya']=="magazin") {?>
	<div class="post-more"><a class="button-default medium" href="<?php echo base_url('anasehife/magazindetal/');echo $bilgi['tool'];echo $bilgi['title']; ?>" rel="bookmark"><i class="fa fa-long-arrow-right"></i>Devamı</a></div>
	<?php }elseif ($bilgi['kateqoriya']=="idman") {?>
		<div class="post-more"><a class="button-default medium" href="<?php echo base_url('anasehife/idmandetal/');echo $bilgi['tool'];echo $bilgi['title']; ?>" rel="bookmark"><i class="fa fa-long-arrow-right"></i>Devamı</a></div>
		<?php }elseif ($bilgi['kateqoriya']=="maraqli") {?>
		<div class="post-more"><a class="button-default medium" href="<?php echo base_url('anasehife/maraqlidetal/');echo $bilgi['tool'];echo $bilgi['title']; ?>" rel="bookmark"><i class="fa fa-long-arrow-right"></i>Devamı</a></div>
		<?php } ?>
<div class="clearfix"></div>
</div>
</div>
</article>

<?php } ?>

</div>
</div>
</div>
<div class="not_duplicate_array" data-not_duplicate=""></div>
</div>
<?php echo $linkler; ?>

</div>