
<div id="widget_counter-4" class="widget widget-statistics widget-margin-custom widget-margin-20">
<div class="widget-title">
<h3>Sosial Mediya</h3></div>
<div class="clearfix"></div>
<div class="widget-wrap">
<div class="social-ul">
<ul class=" social-background">
<li class="social-facebook">
<a href="http://www.facebook.com" target="_blank"><i class="fa fa-facebook"></i></a>
</li>
<li class="social-twitter">
<a href="http://www.twitter.com" target="_blank"><i class="fa fa-twitter"></i></a>
</li>
<li class="social-gplus">
<a href="http://www.google.com" target="_blank"><i class="fa fa-google-plus"></i></a>
</li>
<li class="social-instagram">
<a href="http://www.instagram.com" target="_blank"><i class="fa fa-instagram"></i></a>
</li>
</ul>
</div>
<div class="clearfix"></div>
</div>
</div>