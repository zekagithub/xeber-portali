
<footer id="main-footer">
<div class="top-footer top-footer-2" style=" padding-top:60px; padding-bottom:60px;">
<div class="container">
<div class="row">
<div class="col-md-4">
<div id="about_me-widget-4" class="widget widget-about">
<div class="widget-title">
<h3>Haqqımızda</h3></div>
<div class="clearfix"></div>
<div class="widget-wrap">
<div class="about-widget">
<div class="widget-about-img">
<?php $bilgi= siteayarlari(); foreach ($bilgi as $bilgi) {?>
<a href='<?php echo base_url(); ?>' data-rel='prettyPhoto'><img alt='' src=''></a> </div>

<p style='margin-top: 20px'><?php echo $bilgi['site_bilgi']; ?></p>
<br><br>
<p>Telefon:&nbsp<?php echo $bilgi['site_telefon'] ?></p>

<br>
<p>E-mail:&nbsp<?php echo $bilgi['site_mail'] ?></p>
<br>
<p>Adres:&nbsp<?php echo $bilgi['site_adres'] ?></p>



<?php } ?>
</div>
</div>
</div>
</div>
<div class="col-md-4">
<div id="widget_posts-7" class="widget widget-posts">
<div class="widget-title">
<h3>Son Xəbərlər</h3></div>
<div class="clearfix"></div>
<div class="widget-wrap">
<ul class='widget-posts'>
<?php $sxeber=sonxeberler2();foreach ($sxeber as $sxeber) {?>

<li class="widget-posts-image">
<div class="box-news-small">
<div class="box-news-img">
	<?php if ($sxeber['kateqoriya']=="siyasi") {?>
	
<img alt='<?php echo $sxeber['title']; ?>' width='94' height='73' src='<?php echo base_url();echo $sxeber['mini']; ?>'>
<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/siyasetdetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"></a></div>
<?php }elseif ($sxeber['kateqoriya']=="ekonomi") {?>
<img alt='<?php echo $sxeber['title']; ?>' width='94' height='73' src='<?php echo base_url();echo $sxeber['mini']; ?>'>
<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/ekonomidetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"></a></div>
<?php }elseif ($sxeber['kateqoriya']=="medeniyyet") {?>
<img alt='<?php echo $sxeber['title']; ?>' width='94' height='73' src='<?php echo base_url();echo $sxeber['mini']; ?>'>
<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/medeniyyetdetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"></a></div>
<?php }elseif ($sxeber['kateqoriya']=="magazin") {?>
<img alt='<?php echo $sxeber['title']; ?>' width='94' height='73' src='<?php echo base_url();echo $sxeber['mini']; ?>'>
<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/magazindetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"></a></div>
<?php }elseif ($sxeber['kateqoriya']=="idman") {?>
<img alt='<?php echo $sxeber['title']; ?>' width='94' height='73' src='<?php echo base_url();echo $sxeber['mini']; ?>'>
<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/idmandetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"></a></div>
<?php }elseif ($sxeber['kateqoriya']=="maraqli") {?>
<img alt='<?php echo $sxeber['title']; ?>' width='94' height='73' src='<?php echo base_url();echo $sxeber['mini']; ?>'>
<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/maraqlidetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"></a></div>
<?php } ?>
</div>
<div class="box-news-content">
	<?php if ($sxeber['kateqoriya']=="siyasi") {?>

<div class="box-news-title"><a href="<?php echo base_url('anasehife/siyasidetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"><?php echo $sxeber['title']; ?></a></div>
<?php }elseif ($sxeber['kateqoriya']=="ekonomi") {?>
	<div class="box-news-title"><a href="<?php echo base_url('anasehife/ekonomiidetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"><?php echo $sxeber['title']; ?></a></div>
<?php }elseif ($sxeber['kateqoriya']=="medeniyyet") {?>
<div class="box-news-title"><a href="<?php echo base_url('anasehife/medeniyyyetdetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"><?php echo $sxeber['title']; ?></a></div>
<?php }elseif ($sxeber['kateqoriya']=="magazin") {?>
	<div class="box-news-title"><a href="<?php echo base_url('anasehife/magazindetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"><?php echo $sxeber['title']; ?></a></div>
<?php }elseif ($sxeber['kateqoriya']=="idman") {?>
	<div class="box-news-title"><a href="<?php echo base_url('anasehife/idmandetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"><?php echo $sxeber['title']; ?></a></div>
<?php }elseif ($sxeber['kateqoriya']=="maraqli") {?>
<div class="box-news-title"><a href="<?php echo base_url('anasehife/maraqlidetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"><?php echo $sxeber['title']; ?></a></div>
<?php } ?>

<div class="box-news-meta">
<time class="box-news-meta-date"><i class="fa fa-calendar"></i><?php echo $sxeber['tarix']; ?></time>
<a class="box-news-meta-comment"><i class="fa fa-comments-o"></i><?php echo $sxeber['hit']; ?></a>
</div>
<div class="clearfix"></div>
</div>
<div class="clearfix"></div>
</div>
</li>
<?php } ?>


</ul>
</div>
</div>
</div>


<div class="col-md-4">
<div id="widget_posts-7" class="widget widget-posts">
<div class="widget-title">
<h3>Çox oxunan xəbərlər</h3></div>
<div class="clearfix"></div>
<div class="widget-wrap">
<ul class='widget-posts'>
<?php $sxeber=sonxeberler2();foreach ($sxeber as $sxeber) {?>

<li class="widget-posts-image">
<div class="box-news-small">
<div class="box-news-img">
	<?php if ($sxeber['kateqoriya']=="siyasi") {?>
	
<img alt='<?php echo $sxeber['title']; ?>' width='94' height='73' src='<?php echo base_url();echo $sxeber['mini']; ?>'>
<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/siyasetdetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"></a></div>
<?php }elseif ($sxeber['kateqoriya']=="ekonomi") {?>
<img alt='<?php echo $sxeber['title']; ?>' width='94' height='73' src='<?php echo base_url();echo $sxeber['mini']; ?>'>
<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/ekonomidetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"></a></div>
<?php }elseif ($sxeber['kateqoriya']=="medeniyyet") {?>
<img alt='<?php echo $sxeber['title']; ?>' width='94' height='73' src='<?php echo base_url();echo $sxeber['mini']; ?>'>
<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/medeniyyetdetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"></a></div>
<?php }elseif ($sxeber['kateqoriya']=="magazin") {?>
<img alt='<?php echo $sxeber['title']; ?>' width='94' height='73' src='<?php echo base_url();echo $sxeber['mini']; ?>'>
<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/magazindetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"></a></div>
<?php }elseif ($sxeber['kateqoriya']=="idman") {?>
<img alt='<?php echo $sxeber['title']; ?>' width='94' height='73' src='<?php echo base_url();echo $sxeber['mini']; ?>'>
<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/idmandetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"></a></div>
<?php }elseif ($sxeber['kateqoriya']=="maraqli") {?>
<img alt='<?php echo $sxeber['title']; ?>' width='94' height='73' src='<?php echo base_url();echo $sxeber['mini']; ?>'>
<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/maraqlidetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"></a></div>
<?php } ?>
</div>
<div class="box-news-content">
	<?php if ($sxeber['kateqoriya']=="siyasi") {?>

<div class="box-news-title"><a href="<?php echo base_url('anasehife/siyasidetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"><?php echo $sxeber['title']; ?></a></div>
<?php }elseif ($sxeber['kateqoriya']=="ekonomi") {?>
	<div class="box-news-title"><a href="<?php echo base_url('anasehife/ekonomiidetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"><?php echo $sxeber['title']; ?></a></div>
<?php }elseif ($sxeber['kateqoriya']=="medeniyyet") {?>
<div class="box-news-title"><a href="<?php echo base_url('anasehife/medeniyyyetdetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"><?php echo $sxeber['title']; ?></a></div>
<?php }elseif ($sxeber['kateqoriya']=="magazin") {?>
	<div class="box-news-title"><a href="<?php echo base_url('anasehife/magazindetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"><?php echo $sxeber['title']; ?></a></div>
<?php }elseif ($sxeber['kateqoriya']=="idman") {?>
	<div class="box-news-title"><a href="<?php echo base_url('anasehife/idmandetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"><?php echo $sxeber['title']; ?></a></div>
<?php }elseif ($sxeber['kateqoriya']=="maraqli") {?>
<div class="box-news-title"><a href="<?php echo base_url('anasehife/maraqlidetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"><?php echo $sxeber['title']; ?></a></div>
<?php } ?>

<div class="box-news-meta">
<time class="box-news-meta-date"><i class="fa fa-calendar"></i><?php echo $sxeber['tarix']; ?></time>
<a class="box-news-meta-comment"><i class="fa fa-comments-o"></i><?php echo $sxeber['hit']; ?></a>
</div>
<div class="clearfix"></div>
</div>
<div class="clearfix"></div>
</div>
</li>
<?php } ?>

</ul>
</div>
</div>
</div>

</div>
</div>
</div>

<div id="footer" class='main-block footer-normal footer-social-copyrights footer-have-top footer-2'>
<div class="container">
<div class="social-ul">
<ul>
	
<li class="social-facebook"><a class="tooltip-n" href="http://www.facebook.com" target='_blank'><i class="fa fa-facebook"></i></a></li>
<li class="social-twitter"><a class="tooltip-n" href="http://www.twitter.com" target='_blank'><i class="fa fa-twitter"></i></a></li>
<li class="social-instargram"><a class="tooltip-n" href="http://www.instagram.com" target='_blank'><i class="fa fa-instagram"></i></a></li>
<li class="social-google"><a class="tooltip-n" href="http://www.google.com" target='_blank'><i class="fa fa-google-plus"></i></a></li>
</ul>
</div>

<div class="copyrights">Copyright <?php echo date('Y'); ?> Coder By <a href="<?php echo base_url(); ?>" target=_blank> Zəka Məmmədov</a></div>
</div>
</div>
</footer>
<div class="clearfix"></div>
</div>
</div>
<div class="go-up"><i class="fa fa-chevron-up"></i></div>


<?php $this->load->view('front/include/script'); ?>