<div id="widget_posts-5" class="widget widget-posts">
<div class="widget-title">
<h3>Son Xəbərlər</h3></div>
<div class="clearfix"></div>
<div class="widget-wrap">
<ul class='widget-posts'>
<?php $bilgi=sonxeberler(); foreach ($bilgi as $bilgi) {?>
	
<li class="widget-posts-image">
<div class="box-news-small">
<div class="box-news-img">
<img alt='<?php echo $bilgi['title']; ?>' width='94' height='73' src='<?php echo base_url();echo $bilgi['mini']; ?>'>
<?php if ($bilgi['kateqoriya']=="siyasi") {?>

<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/siyasetdetal/');echo $bilgi['tool']; ?>" title="<?php echo $bilgi ['title']; ?>" rel="bookmark"></a></div>
<?php } elseif ($bilgi['kateqoriya']=="iqtisadi") {?>
<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/ekonomidetal/');echo $bilgi['tool']; ?>" title="<?php echo $bilgi ['title']; ?>" rel="bookmark"></a></div>
<?php }elseif ($bilgi['kateqoriya']=="medeniyyet") {?>
<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/medeniyyetdetal/');echo $bilgi['tool']; ?>" title="<?php echo $bilgi ['title']; ?>" rel="bookmark"></a></div>
<?php }elseif ($bilgi['kateqoriya']=="magazin") {?>
<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/magazindetal/');echo $bilgi['tool']; ?>" title="<?php echo $bilgi ['title']; ?>" rel="bookmark"></a></div>

<?php }elseif ($bilgi['kateqoriya']=="idman") {?>
<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/idmandetal/');echo $bilgi['tool']; ?>" title="<?php echo $bilgi ['title']; ?>" rel="bookmark"></a></div>
<?php }elseif ($bilgi['kateqoriya']=="maraqli") {?>
<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/maraqlidetal/');echo $bilgi['tool']; ?>" title="<?php echo $bilgi ['title']; ?>" rel="bookmark"></a></div>
<?php } ?>


</div>

<div class="box-news-content">
	<?php if ($bilgi['kateqoriya']=="siyasi") {?>
	
<div class="box-news-title">
	<a href="<?php echo base_url('anasehife/siyasetdetal/'); echo $bilgi['tool']; ?>" title="<?php echo $bilgi['title'];?>" rel="bookmark"><?php echo $bilgi['title'];?></a></div>
<?php }elseif ($bilgi['kateqoriya']=="ekonomi") {?>
<div class="box-news-title">
	<a href="<?php echo base_url('anasehife/ekonomidetal/'); echo $bilgi['tool']; ?>" title="<?php echo $bilgi['title'];?>" rel="bookmark"><?php echo $bilgi['title'];?></a></div>
	<?php }elseif ($bilgi['kateqoriya']=="medeniyyet") {?>
	<div class="box-news-title">
	<a href="<?php echo base_url('anasehife/medeniyyetdetal/'); echo $bilgi['tool']; ?>" title="<?php echo $bilgi['title'];?>" rel="bookmark"><?php echo $bilgi['title'];?></a></div>
	<?php }elseif ($bilgi['kateqoriya']=="magazin") {?>
	<div class="box-news-title">
	<a href="<?php echo base_url('anasehife/magazindetal/'); echo $bilgi['tool']; ?>" title="<?php echo $bilgi['title'];?>" rel="bookmark"><?php echo $bilgi['title'];?></a></div>
	<?php }elseif ($bilgi['kateqoriya']=="idman") {?>
	<div class="box-news-title">
	<a href="<?php echo base_url('anasehife/idmandetal/'); echo $bilgi['tool']; ?>" title="<?php echo $bilgi['title'];?>" rel="bookmark"><?php echo $bilgi['title'];?></a></div>
	<?php }elseif ($bilgi['kateqoriya']=="maraqli") {?>
	<div class="box-news-title">
	<a href="<?php echo base_url('anasehife/maraqlidetal/'); echo $bilgi['tool']; ?>" title="<?php echo $bilgi['title'];?>" rel="bookmark"><?php echo $bilgi['title'];?></a></div>
<?php } ?>
<div class="box-news-meta">
<time class="box-news-meta-date"><i class="fa fa-calendar"></i><?php echo $bilgi['tarix']; ?></time>
<a class="box-news-meta-comment"><i class="fa fa-comments-o"></i>0</a>
</div>
<div class="clearfix"></div>
</div>
<div class="clearfix"></div>
</div>
</li>
<?php } ?>

</ul>
</div>
</div>