
<div class='widget tabs-warp widget-tabs'>
<div class="widget-title widget-title-tabs">
<ul class="tabs tabs359">
<li class="tab"><a href="#">Çox Oxunan</a></li>
<li class="tab"><a href="#">Comments</a></li>
<li class="tab"><a href="#">Tag</a></li>
<li class="clearfix"></li>
</ul>
</div>
<div class="widget-wrap">
<div class='tab-inner-warp tab-inner-warp359'>
<ul class='widget-posts'>
	<?php $sxeber=hitxeberler();foreach ($sxeber as $sxeber ) {?>
	
<li class="widget-posts-slideshow">
<div class="box-news-small">
<div class="box-news-img">
<?php if ($sxeber['kateqoriya']=="siyasi") {?>
<img alt='<?php echo $sxeber['title']; ?>' width='94' height='73' src='<?php echo base_url();echo $sxeber['mini']; ?>'>
<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/siyasetdetal/');echo $sxeber['tool']; echo $sxeber['title']; ?>" rel="bookmark"></a></div>
<?php }elseif ($sxeber['kateqoriya']=="ekonomi") {?>
<img alt='<?php echo $sxeber['title']; ?>' width='94' height='73' src='<?php echo base_url();echo $sxeber['mini']; ?>'>
<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/ekonomidetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"></a></div>
<?php }elseif ($sxeber['kateqoriya']=="medeniyyet") {?>
<img alt='<?php echo $sxeber['title']; ?>' width='94' height='73' src='<?php echo base_url();echo $sxeber['mini']; ?>'>
<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/medeniyyetdetal/');echo $sxeber['tool']; echo $sxeber['title']; ?>" rel="bookmark"></a></div>
<?php }elseif ($sxeber['kateqoriya']=="magazin") {?>
<img alt='<?php echo $sxeber['title']; ?>' width='94' height='73' src='<?php echo base_url();echo $sxeber['mini']; ?>'>
<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/magazindetal/');echo $sxeber['tool']; echo $sxeber['title']; ?>" rel="bookmark"></a></div>
<?php }elseif ($sxeber['kateqoriya']=="idman") {?>
<img alt='<?php echo $sxeber['title']; ?>' width='94' height='73' src='<?php echo base_url();echo $sxeber['mini']; ?>'>
<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/idmandetal/');echo $sxeber['tool'];echo $sxeber['title']; ?>" rel="bookmark"></a></div>
<?php }elseif ($sxeber['kateqoriya']=="maraqli") {?>
	<img alt='<?php echo $sxeber['title']; ?>' width='94' height='73' src='<?php echo base_url();echo $sxeber['mini']; ?>'>
<div class="box-news-overlay"><a href="<?php echo base_url('anasehife/maraqlidetal/');echo $sxeber['tool']; ?>" rel="bookmark"></a></div>
<?php } ?>
</div>
<div class="box-news-content">
<?php if ($sxeber['kateqoriya']=="siyasi") {?>
<div class="box-news-title"><a href="<?php echo base_url('anasehife/siyasetdetal/');echo $sxeber['tool']; ?>" title="<?php echo $sxeber['title']; ?>" rel="bookmark"><?php echo $sxeber['title']; ?></a></div>
<?php }elseif ($sxeber['kateqoriya']=="ekonomi") {?>
<div class="box-news-title"><a href="<?php echo base_url('anasehife/ekonomidetal/');echo $sxeber['tool']; ?>" title="<?php echo $sxeber['title']; ?>" rel="bookmark"><?php echo $sxeber['title']; ?></a></div>
<?php }elseif ($sxeber['kateqoriya']=="ekonomi") {?>
<div class="box-news-title"><a href="<?php echo base_url('anasehife/ekonomidetal/');echo $sxeber['tool']; ?>" title="<?php echo $sxeber['title']; ?>" rel="bookmark"><?php echo $sxeber['title']; ?></a></div>
<?php }elseif ($sxeber['kateqoriya']=="medeniyyet") {?>
<div class="box-news-title"><a href="<?php echo base_url('anasehife/medeniyyetdetal/');echo $sxeber['tool']; ?>" title="<?php echo $sxeber['title']; ?>" rel="bookmark"><?php echo $sxeber['title']; ?></a></div>
<?php }elseif ($sxeber['kateqoriya']=="magazin") {?>
<div class="box-news-title"><a href="<?php echo base_url('anasehife/magazindetal/');echo $sxeber['tool']; ?>" title="<?php echo $sxeber['title']; ?>" rel="bookmark"><?php echo $sxeber['title']; ?></a></div>
<?php }elseif ($sxeber['kateqoriya']=="idman") {?>
<div class="box-news-title"><a href="<?php echo base_url('anasehife/idmandetal/');echo $sxeber['tool']; ?>" title="<?php echo $sxeber['title']; ?>" rel="bookmark"><?php echo $sxeber['title']; ?></a></div>
<?php }elseif ($sxeber['kateqoriya']=="maraqli") {?>
<div class="box-news-title"><a href="<?php echo base_url('anasehife/maraqlidetal/');echo $sxeber['tool']; ?>" title="<?php echo $sxeber['title']; ?>" rel="bookmark"><?php echo $sxeber['title']; ?></a></div>
<?php } ?>
<div class="box-news-meta">
<time class="box-news-meta-date"><i class="fa fa-calendar"></i><?php echo $sxeber['tarix'] ?></time>
<a class="box-news-meta-comment"><i class="fa fa-comments-o"></i>7</a>
</div>
<div class="clearfix"></div>
</div>
<div class="clearfix"></div>
</div>
</li>

<?php } ?>

</ul>
</div>
<div class='tab-inner-warp tab-inner-warp359'>
<div class='widget-comments'>
<ol class='commentlist clearfix'>
	<?php $serh=serhcek();foreach ($serh as $serh) {?>
	
<li class="comment">
<div class="comment-body">
<div class="avatar">
<a href="php">
<img alt='avatar' src='<?php echo base_url('assets/front/'); ?>images/avatar.png'>
</a>
</div>
<div class="comment-text">
<div class="author clearfix">
<div class="comment-meta">
<span class="comment-author fn"><a href='#' target='_blank'><?php echo $serh['adi']; ?></a></span>
<div class="clearfix"></div>
</div>
</div>
<div class="text">
<p><a href="#"><?php echo $serh['serh']; ?></a></p>
</div>
</div>
</div>
</li>

<?php } ?>

</ol>
</div>
</div>
<div class='tab-inner-warp tab-inner-warp359'>
	<!--tag-->
<div class='widget_tag_cloud'>
	<?php $taglar=tagcek(); foreach ($taglar as $tag ) {
	$tag=explode(",",$tag['tag']);
	foreach ($tag as $etiket) {?>


<a href="#" class="tag-cloud-link" style="font-size: 13.6pt;"><?php echo $etiket ?></a>
<?php }} ?>

</div>
</div>
</div>
</div>