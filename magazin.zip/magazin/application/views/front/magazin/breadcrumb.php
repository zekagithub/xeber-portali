<div class="breadcrumbs-main main-block breadcrumbs-main-3">
<div class="container">
<div class="breadcrumbs">
<div class="crumbs">
<a href="<?php echo base_url(); ?>"><i class="fa fa-home"></i>Anasayfa</a>
<span class="crumbs-span">&raquo;</span>
<span class="current">Magazin</span>
</div>
</div>
</div>
</div>
