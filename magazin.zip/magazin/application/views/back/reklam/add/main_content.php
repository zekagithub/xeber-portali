    <section class="content">
    <div class="col-md-">
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Reklam elave etme sehifesi</h3>
            </div>
            <form method="post" action="<?php echo base_url('admin/reklamelaveetme'); ?>" enctype="multipart/form-data" class="form-horizontal">
              <div class="box-body">
                  <div class="form-group">
                  <label class="col-sm-2 control-label">Sirket </label>
                  <div class="col-sm-7">
                   <input type="text" value="" name="sirket" class="form-control"  placeholder="Sirket adi">
                  </div>
                </div>   
              </div>
                 <div class="box-body">
                  <div class="form-group">
                  <label class="col-sm-2 control-label">Link </label>
                  <div class="col-sm-7">
                   <input type="text" value="" name="link" class="form-control"  placeholder="Yonlendirme linki">
                  </div>
                </div>   
              </div>
                  <div class="box-body">
                  <div class="form-group">
                  <label class="col-sm-2 control-label">Sekil</label>
                  <div class="col-sm-7">
                   <input type="file" value="" name="sekil" class="form-control">
                  </div>
                </div>   
              </div>
                 <div class="box-body">
                  <div class="form-group">
                  <label class="col-sm-2 control-label">Baslangic tarixi </label>
                  <div class="col-sm-3">
                   <input type="date" value="" name="baslangic" class="form-control">
                  </div>

                  <label class="col-sm-2 control-label">Bitis tarixi  </label>
                  <div class="col-sm-3">
                   <input type="date" value="" name="bitis" class="form-control">
                  </div>
                </div>  
              </div>
             
             
              <div class="box-footer">
           <a class="btn btn-warning" href="<?php echo base_url('admin/reklam'); ?>">Imtina Et</a>
              <button type="submit" class="btn btn-primary pull-right">Elave Et</button>
              </div>
            </form>
          </div>
          </div>
      </section>
      <div class="clearfix"></div>
         

