    <section class="content">
    <div class="col-md-">
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Reklam deyisdirme sehifesi</h3>
            </div>
            <form method="post" action="<?php echo base_url('admin/reklamguncelle'); ?>" enctype="multipart/form-data" class="form-horizontal">
              <div class="box-body">
                  <div class="form-group">
                  <label class="col-sm-2 control-label">Sirket</label>
                  <div class="col-sm-7">
                   <input type="text" value="<?php echo $bilgi['sirket']; ?>" name="sirket" class="form-control"  placeholder="sirketin adi">
                   <input type="hidden" name="id" value="<?php echo $bilgi['id']; ?>">
                   <input type="hidden" name="status" value="<?php echo $bilgi['status']; ?>">
                  </div>
                </div>   
              </div>
                <div class="box-body">
                  <div class="form-group">
                  <label class="col-sm-2 control-label">  Url</label>
                  <div class="col-sm-7">
                  <input type="text" value="<?php echo $bilgi['link']; ?>" name="link" class="form-control" >
                  </div>
                </div>   
              </div>
                  <div class="box-body">
                  <div class="form-group">
                  <label class="col-sm-2 control-label">  Sekil</label>
                  <div class="col-sm-7">
                   <input type="file" value="" name="sekil" class="form-control" >
                  </div>
                </div>   
              </div>
              <div class="box-body">
                  <div class="form-group">
                  <label class="col-sm-2 control-label">  Baslangic tarixi</label>
                  <div class="col-sm-3">
                  <input type="date" value="<?php echo $bilgi['baslangic']; ?>" name="baslangic" class="form-control" >
                  </div>

                  <label class="col-sm-2 control-label"> Bitis tarixi</label>
                  <div class="col-sm-3">
                 <input type="date" value="<?php echo $bilgi['bitis']; ?>" name="bitis" class="form-control">
                  </div>
                </div>   
              </div>
                 <div class="box-body">
                  <div class="form-group">
                  <label class="col-sm-2 control-label"> Movcud Sekil</label>
                  <div class="col-sm-7">
                    <img src="<?php echo base_url($bilgi['tmb']); ?>"  class="profile-user-image image-responsive" style="width: 200px; height: 120px;">
                    <p class="text-blue">Deyisdirmeseniz sekil secmeyin</p>
                  </div>
                </div>   
              </div>
                
                
             
             
              <div class="box-footer">
           <a class="btn btn-warning" href="<?php echo base_url('admin/reklam'); ?>">Imtina Et</a>
              <button type="submit" class="btn btn-info pull-right">Deyisdir</button>
              </div>
            </form>
          </div>
          </div>
      </section>
      <div class="clearfix"></div>
         

