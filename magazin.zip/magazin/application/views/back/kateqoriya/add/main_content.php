    <section class="content">
    <div class="col-md-">
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Kateqoriya elave etme sehifesi</h3>
            </div>
            <form method="post" action="<?php echo base_url('admin/kateqoriyaelaveetme'); ?>" class="form-horizontal">
              <div class="box-body">
                  <div class="form-group">
                  <label class="col-sm-2 control-label">Kateqoriya Basliqi</label>

                  <div class="col-sm-7">
                   <input type="text" value="" name="basliq" class="form-control"  placeholder="Kateqoriya Basliqi">
                  </div>
                </div>   
              </div>
              <div class="box-footer">
           <a class="btn btn-warning" href="<?php echo base_url('admin/kateqoriya'); ?>">Imtina Et</a>
              <button type="submit" class="btn btn-primary pull-right">Elave Et</button>
              </div>
            </form>
          </div>
          </div>
      </section>
      <div class="clearfix"></div>
         

