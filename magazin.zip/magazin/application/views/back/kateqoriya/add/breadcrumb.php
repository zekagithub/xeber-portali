<section class="content-header">
      <h1>Site Admin<small>kontrol paneli</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url('admin');?>"><i class="fa fa-dashboard"></i>Anasehife</a></li>
        <li><a href="<?php echo base_url('admin/Kateqoriya'); ?>"><i class="fa fa-indent">Kateqoriya</i></a></li>
          <li class="active">Kateqoriya elave et</li>

      </ol>
    </section>