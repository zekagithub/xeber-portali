 <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Comment Listi</h3>
            </div>
                <?php echo $this->session->flashdata('status'); ?>

            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                <th>Nomre</th>
                <th>Ad ve Soyad</th>
                <th>Email</th>
                <th>Commentin tarixi</th>
                <th>Status</th>
                <th style="width: 100px;">Əməliyyat</th>


                </tr>
                </thead>
                <tbody>
                  <tr>
                  <?php $sayi=1; foreach ($bilgi as $bilgi) {?>
                  <td><?php echo $sayi++; ?></td>
                  <td><?php echo $bilgi['adi']; ?></td>
                  <td><?php echo $bilgi['email']; ?></td>
                  <td><?php echo $bilgi['tarix']; ?></td>


<td><input class="toggle_check" data-on="aktiv" data-onstyle="success" data-off="passiv" data-offstyle="danger" type="checkbox" dataID="<?php echo $bilgi['id']; ?>" dataURL="<?php echo base_url('admin/commentset'); ?>" <?php echo ($bilgi['status'] == 1 ) ? "checked" : ""; ?>></td>
                 

                  <td><a href="<?php echo base_url('admin/commentdeyis/'.$bilgi['id'].'');?>"><button type="button" class="btn btn-info"  name="button" >Deyisdir</button></a>
                    <a href="<?php echo base_url('admin/commentsil/'.$bilgi['id'].'/id/serh');?>"><button type="button" class="btn btn-danger"  name="button" >Sil</button></a></td>
   
</tr>
               <?php } ?>
               </tbody>

                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
         
