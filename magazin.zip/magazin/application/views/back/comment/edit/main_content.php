    <section class="content">
    <div class="col-md-">
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Comment deyisdirme sehifesi</h3>
            </div>
            <form method="post" action="<?php echo base_url('admin/commentguncelle'); ?>" class="form-horizontal">
              <div class="box-body">
                  <div class="form-group">
                  <label class="col-sm-2 control-label">Ad ve Soyad</label>
                  <div class="col-sm-7">
                   <input type="text" value="<?php echo $bilgi['adi']; ?>" name="adi" class="form-control"  placeholder="">
                   <input type="hidden" name="id" value="<?php echo $bilgi['id']; ?>">
                   <input type="hidden" name="status" value="<?php echo $bilgi['status']; ?>">
                  </div>
                </div>   
              </div>
              
                  
          
                 <div class="box-body">
                  <div class="form-group">
                  <label class="col-sm-2 control-label"> Comment</label>
                  <div class="col-sm-7">
                    <textarea name="comment" cols="80" rows="8"><?php echo $bilgi['serh']; ?></textarea>
                  </div>
                </div>   
              </div>
                
                
            
              <div class="box-footer">
           <a class="btn btn-warning" href="<?php echo base_url('admin/comment'); ?>">Imtina Et</a>
              <button type="submit" class="btn btn-info pull-right">Deyisdir</button>
              </div>
            </form>
          </div>
          </div>
      </section>
      <div class="clearfix"></div>
         

