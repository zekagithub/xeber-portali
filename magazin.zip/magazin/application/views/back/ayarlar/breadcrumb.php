<section class="content-header">
      <h1>Site Admin<small>kontrol paneli</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url('admin'); ?>"><i class="fa fa-dashboard"></i>Anasehife</a></li>
        <li class="active">Site ayarlari</li>
      </ol>
    </section>