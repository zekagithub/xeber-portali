    <section class="content">
    <div class="col-md-">
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Sayt Ayarlarini Deyisdirmek</h3>
            </div>
            <form method="post" action="<?php echo base_url('admin/ayarguncelle'); ?>" class="form-horizontal">
              <div class="box-body">
                <div class="form-group">
                  <label class="col-sm-2 control-label">Sayt Basliqi</label>

                  <div class="col-sm-7">
                    <input type="text" value="<?php echo $bilgi['title'];?>"  name="basliq" class="form-control"  placeholder="Sayt basliqi">
                    <input type="hidden" name="id" value="<?php echo $bilgi['id']; ?>">
                  </div>
                </div>
                 <div class="form-group">
                  <label class="col-sm-2 control-label">Sayt Maili</label>

                  <div class="col-sm-7">
                    <input type="email" value="<?php echo $bilgi['site_mail']; ?>" name="email" class="form-control"  placeholder="Sayt mali">
                  </div>
                </div>
             <div class="form-group">
                  <label class="col-sm-2 control-label">Sayt Telefon</label>

                  <div class="col-sm-7">
                    <input type="text" value="<?php echo $bilgi['site_telefon']; ?>" name="telefon" class="form-control"  placeholder="Sayt Telefonu">
                  </div>
                </div>
                  <div class="form-group">
                  <label class="col-sm-2 control-label">Sayt Aciqlama</label>

                  <div class="col-sm-7">
                    <input type="text" value="<?php echo $bilgi['site_desc']; ?>" name="desc" class="form-control"  placeholder="Sayt Aciqlamasi">
                  </div>
                </div>
                  <div class="form-group">
                  <label class="col-sm-2 control-label">Sayt Acar sozleri</label>

                  <div class="col-sm-7">
                    <input type="text" value="<?php echo $bilgi['site_keyw']; ?>" name="keyw" class="form-control"  placeholder="Sayt Acar sozleri">
                  </div>
                </div>
                   <div class="form-group">
                  <label class="col-sm-2 control-label">Sayt Melumat</label>
                  <div class="col-sm-10">
                    <textarea name="melumat" rows="8" cols="80" > <?php echo $bilgi['site_bilgi']; ?></textarea>
                  </div>
                </div>
                   <div class="form-group">
                  <label class="col-sm-2 control-label">Sayt Adres</label>
                    <div class="col-sm-10">
                   <textarea name="adres"  rows="8"  cols="80" ><?php echo $bilgi['site_adres']; ?></textarea>
                </div>
                </div>
                
              </div>
              <div class="box-footer">
           <a class="btn btn-warning" href="<?php echo base_url('admin/ayarlar'); ?>">Imtina Et</a>
              <button type="submit" class="btn btn-info pull-right">Qeyd Et</button>
              </div>
            </form>
          </div>
          </div>
      </section>
      <div class="clearfix"></div>
         

