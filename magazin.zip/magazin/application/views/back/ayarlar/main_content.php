 <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Sayt Ayarlari</h3>
            </div>
            <?php echo $this->session->flashdata('veziyyet'); ?>
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                 <th>Nomre</th>
                  <th>Sayt Basliq</th>
                  <th>Url</th>
                  <th>Mail</th>
                  <th>Tel</th>
                  <th>Aciqlamasi</th>
                  <th>Keywords</th>


                 <th>Deyiş</th>
                </tr>
                </thead>
                <tbody>
                  <?php $sayi=1; foreach ($bilgi as $bilgi) {?>
                <tr>
                  <td><?php echo $sayi++; ?></td>
                  <td><?php echo $bilgi['title']; ?></td>
                  <td><?php echo $bilgi['url']; ?></td>
                  <td><?php echo $bilgi['site_mail']; ?></td>
                  <td><?php echo $bilgi['site_telefon']; ?></td>
                  <td><?php echo $bilgi['site_desc']; ?></td>
                  <td><?php echo $bilgi['site_keyw']; ?></td>

                  <td><a href="<?php echo base_url('admin/ayardeyisdir/'.$bilgi['id'].''); ?>"><button type="button" class="btn btn-info"  name="button" >Deyisdir</button></a></td>

                </tr>
               <?php } ?>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
         
