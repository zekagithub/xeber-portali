<section class="content-header">
      <h1>Site Admin<small>kontrol paneli</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url('admin');?>"><i class="fa fa-dashboard"></i>Anasehife</a></li>
        <li><a href="<?php echo base_url('admin/ayarlar'); ?>"><i class="fa fa-gears">Sosialmediya ayarlari</i></a></li>
          <li class="active">Sosialmediya deyisdir</li>

      </ol>
    </section>