<section class="content-header">
      <h1>Site Admin<small>kontrol paneli</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url('admin');?>"><i class="fa fa-dashboard"></i>Anasehife</a></li>
        <li><a href="<?php echo base_url('admin/sosialmediya'); ?>"><i class="fa fa-edge">Sosial mediya</i></a></li>
          <li class="active">sosial mediya elave et</li>

      </ol>
    </section>