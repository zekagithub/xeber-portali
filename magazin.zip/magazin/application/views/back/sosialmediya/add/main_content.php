    <section class="content">
    <div class="col-md-">
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Sayt Ayarlarini elave etmek</h3>
            </div>
            <form method="post" action="<?php echo base_url('admin/smediyaelaveetme'); ?>" class="form-horizontal">
              <div class="box-body">
                  <div class="form-group">
                  <label class="col-sm-2 control-label">Sayt Basliqi</label>

                  <div class="col-sm-7">
                   <input type="text" value="" name="basliq" class="form-control"  placeholder="Sayt Basliqi">
                  </div>
                </div>
                  <div class="form-group">
                  <label class="col-sm-2 control-label">Sayt Url</label>

                  <div class="col-sm-7">
                   <input type="text" value="" name="url" class="form-control"  placeholder="Sayt Url">
                  </div>
                </div>
                  
                   
              </div>
              <div class="box-footer">
           <a class="btn btn-warning" href="<?php echo base_url('admin/sosialmediya'); ?>">Imtina Et</a>
              <button type="submit" class="btn btn-primary pull-right">Elave Et</button>
              </div>
            </form>
          </div>
          </div>
      </section>
      <div class="clearfix"></div>
         

