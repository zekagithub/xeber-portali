  <aside class="main-sidebar">
    <section class="sidebar">
      <div class="user-panel">
        <div class="pull-left image">
          <img src="https://scontent.fgyd7-1.fna.fbcdn.net/v/t1.0-9/26733959_2061562700788017_148550674560867504_n.jpg?_nc_cat=0&oh=5f343933c47e6a4870ecb377decd79d7&oe=5B5D5215" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>Adminstrator</p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header text-yellow text-center">Admin Panel</li>
        <li class="treeview">
          <li><a href="<?php echo base_url('admin'); ?>">
            <i class="fa fa-dashboard"></i> <span>Ana sehife</span>
          </a>
        </li>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-gears"></i>
            <span>Umumi Ayarlar</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url('admin/ayarlar'); ?>"><i class="fa fa-circle-o"></i> Sayt Ayarlari</a></li>
            <li><a href="<?php echo base_url('admin/sosialmediya'); ?>"><i class="fa fa-circle-o"></i> Sosial Media Ayarlari</a></li>
            
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-indent"></i>
            <span>Kateqoriya</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url('admin/kateqoriya'); ?>"><i class="fa fa-circle-o"></i> Kateqoriya listi</a></li>
            
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-newspaper-o"></i>
            <span>Xeberler</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url('admin/xeberler'); ?>"><i class="fa fa-circle-o"></i>Xeber siyahisi</a></li>
            
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-edit"></i>
            <span>Redaktorlar</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url('admin/redaktor'); ?>"><i class="fa fa-circle-o"></i> Redaktorlar</a></li>
            
          </ul>
        </li>
      
        <li class="treeview">
          <a href="#">
            <i class="fa fa-envelope"></i>
            <span>Mesajlar</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url('admin/mesaj'); ?>"><i class="fa fa-circle-o"></i> Mesaj siyahisi</a></li>
            
          </ul>
        </li>
       <li class="treeview">
          <a href="#">
            <i class="fa fa-comments"></i>
            <span>Şərhlər</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url('admin/comment'); ?>"><i class="fa fa-circle-o"></i> Şərh siyahisi</a></li>
            
          </ul>
        </li>
 <li class="treeview">
          <a href="#">
            <i class="fa fa-television"></i>
            <span>Reklam</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url('admin/reklam'); ?>"><i class="fa fa-circle-o"></i> Reklam</a></li>
            
          </ul>
        </li>        
        <li class="header text-yellow text-center">DİGƏR</li>
        <li><a href="<?php echo base_url('admin/cixis') ?>"><i class="fa fa-circle-o text-red"></i> <span><button type="button" class="btn btn-danger" name="button">Çıxış et</button></span></a></li>
        <li><a href="<?php echo base_url() ?>" target=_blank><i class="fa fa-circle-o text-yellow" ></i> <span><button type="button" class="btn btn-warning" name="button">Sayti aç</button></span></a></li>
        
      </ul>
    </section>
  </aside>

