<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Yeni Xeber Admin panel</title>
<link rel="shortcut icon" href="<?php echo base_url('assets/front/'); ?>images/favicon.png" type="image/x-icon">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<?php $this->load->view('back/include/style'); ?>
