 <link rel="stylesheet" href="<?php echo base_url('assets/back/');?>/bower_components/bootstrap/dist/css/bootstrap.min.css">
 <link rel="stylesheet" href="<?php echo base_url('assets/back/');?>/bower_components/font-awesome/css/font-awesome.min.css">
 <link rel="stylesheet" href="<?php echo base_url('assets/back/');?>/bower_components/Ionicons/css/ionicons.min.css">
 <link rel="stylesheet" href="<?php echo base_url('assets/back/');?>/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">

 <link rel="stylesheet" href="<?php echo base_url('assets/back/');?>/dist/css/AdminLTE.min.css">
 <link rel="stylesheet" href="<?php echo base_url('assets/back/');?>/dist/css/bootstrap2-toggle.min.css">
 <link rel="stylesheet" href="<?php echo base_url('assets/back/');?>/dist/css/skins/_all-skins.min.css">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">