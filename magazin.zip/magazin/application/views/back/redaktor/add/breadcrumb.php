<section class="content-header">
      <h1>Site Admin<small>kontrol paneli</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url('admin');?>"><i class="fa fa-dashboard"></i>Anasehife</a></li>
        <li><a href="<?php echo base_url('admin/redaktor'); ?>"><i class="fa fa-edit">Redaktor</i></a></li>
          <li class="active"> Redaktor elave et</li>

      </ol>
    </section>