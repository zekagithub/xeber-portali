    <section class="content">
    <div class="col-md-">
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Redaktor deyisdirme sehifesi</h3>
            </div>
            <form method="post" action="<?php echo base_url('admin/redaktorguncelle'); ?>" enctype="multipart/form-data" class="form-horizontal">
              <div class="box-body">
                  <div class="form-group">
                  <label class="col-sm-2 control-label">Adi ve Soyadi</label>
                  <div class="col-sm-7">
                   <input type="text" value="<?php echo $bilgi['adi']; ?>" name="adi" class="form-control"  placeholder="Adi ve Soyadi">
                   <input type="hidden" name="id" value="<?php echo $bilgi['id']; ?>">
                   <input type="hidden" name="status" value="<?php echo $bilgi['status']; ?>">
                  </div>
                </div>   
              </div>
                  <div class="box-body">
                  <div class="form-group">
                  <label class="col-sm-2 control-label">  Sekil</label>
                  <div class="col-sm-7">
                   <input type="file" value="" name="resim" class="form-control" >
                  </div>
                </div>   
              </div>
                 <div class="box-body">
                  <div class="form-group">
                  <label class="col-sm-2 control-label"> Movcud Sekil</label>
                  <div class="col-sm-7">
                    <img src="<?php echo base_url($bilgi['mini']); ?>" class="profile-user-image image-responsive">
                    <p class="text-blue">Deyisdirmeseniz sekil secmeyin</p>
                  </div>
                </div>   
              </div>
                
                
             
             
              <div class="box-footer">
           <a class="btn btn-warning" href="<?php echo base_url('admin/redaktor'); ?>">Imtina Et</a>
              <button type="submit" class="btn btn-info pull-right">Deyisdir</button>
              </div>
            </form>
          </div>
          </div>
      </section>
      <div class="clearfix"></div>
         

