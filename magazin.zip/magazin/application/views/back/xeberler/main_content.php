 <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Xeberler Listi</h3>
             <a href="<?php echo base_url('admin/xeberelave'); ?>" class="btn btn-primary pull-right"><i class="fa fa-plus"></i> Elave et</a>
            </div>
            <?php echo $this->session->flashdata('veziyyet'); ?>
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                 <th>Nomre</th>
                  <th>Xeber Basliq</th>
                   <th>Xeber Kateqoriyasi</th>
                  <th>Manşet Statusu</th>

                   <th>Şərh  Statusu</th>
                   <th>Status</th>
<th style="width: 100px;">Əməliyyat</th>


                </tr>
                </thead>
                <tbody>
                  <?php $sayi=1; foreach ($bilgi as $bilgi) {?>
                <tr>
                  <td><?php echo $sayi++; ?></td>
                  <td><?php echo word_limiter( $bilgi['title'],5); ?></td>
               <td><?php echo $bilgi['kateqoriya']; ?>
                   <td><?php if ($bilgi['sondeqiqe']==1) { ?>
                 <button type="button" class="btn btn-info"  name="button" >Normal Xeber</button>
                  <?php }else{ ?>
                  <button type="button" class="btn btn-warning"  name="button" >Sondeqiqe xeber</button>
                  <?php } ?></td>
                  <td><?php if ($bilgi['yorum']==1) { ?>
                  <button type="button" class="btn btn-info"  name="button" >Şərh acik</button>
                  <?php }else{ ?>
                  <button type="button" class="btn btn-danger"  name="button" >Şərh bagli</button>
                  <?php } ?></td>
                  <td><input class="toggle_check" data-on="aktiv" data-onstyle="success" data-off="passiv" data-offstyle="danger" type="checkbox" dataID="<?php echo $bilgi['id']; ?>" dataURL="<?php echo base_url('admin/xeberset'); ?>" <?php echo ($bilgi['status'] == 1 ) ? "checked" : ""; ?>></td>
                 
                

   
                  <td><a href="<?php echo base_url('admin/xeberdeyis/'.$bilgi['id'].'');?>"><button type="button" class="btn btn-info"  name="button" >Deyisdir</button></a>
                    <a href="<?php echo base_url('admin/xebersil/'.$bilgi['id'].'/id/xeberler');?>"><button type="button" class="btn btn-danger"  name="button" >Sil</button></a></td>
   


                </tr>
               <?php } ?>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
         
