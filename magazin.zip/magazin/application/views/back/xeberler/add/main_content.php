    <section class="content">
    <div class="col-md-">
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Xeber elave etme sehifesi</h3>
            </div>
            <form method="post" action="<?php echo base_url('admin/xeberelaveetme'); ?>" enctype="multipart/form-data" class="form-horizontal">
              <div class="box-body">
                  <div class="form-group">
                  <label class="col-sm-2 control-label">Xeber Basliqi</label>
                  <div class="col-sm-7">
                   <input type="text" value="" name="basliq" class="form-control"  placeholder="Xeber Basliqi">
                  </div>
                </div>   
              </div>
                <div class="box-body">
                  <div class="form-group">
                  <label class="col-sm-2 control-label">Xeber Kateqoriyasi</label>
                  <div class="col-sm-7">
                    <select class="form-control" name="katID">
                      <option value="6">medeniyyet</option>
                      <option value="7">siyasi</option>
                      <option value="8">iqtisadi</option>
                      <option value="9">idman</option>
                      <option value="10">magazin</option>
                      <option value="11">maraqli</option>


                    </select>
                  </div>
                </div>   
              </div>
                <div class="box-body">
                  <div class="form-group">
                  <label class="col-sm-2 control-label">Xeber Şekili</label>
                  <div class="col-sm-7">
                   <input type="file" value="" name="resim" class="form-control">
                  </div>
                </div>   
              </div>
               <div class="box-body">
                  <div class="form-group">
                  <label class="col-sm-2 control-label">Xeber Tarixi</label>
                  <div class="col-sm-7">
                   <input type="date" value="" name="tarix" class="form-control"  >
                  </div>
                </div>   
              </div>
                <div class="box-body">
                  <div class="form-group">
                  <label class="col-sm-2 control-label">Xeber Metni</label>
                  <div class="col-sm-10">
                  <textarea name="xeber" id="editor1" rows="8" cols="80"></textarea>
                  </div>
                </div>   
              </div>
               <div class="box-body">
                  <div class="form-group">
                  <label class="col-sm-2 control-label">Xeber Şerh icazesi</label>
                  <div class="col-sm-7">
                    <select class="form-control" name="serh">
                      <option value="1">Şerh edilsin</option>
                      <option value="2">Şerh edilmesin</option>
                    </select>
                  </div>
                </div>   
              </div>
                <div class="box-body">
                  <div class="form-group">
                  <label class="col-sm-2 control-label">Xeber Manşet icazesi</label>
                  <div class="col-sm-7">
                    <select class="form-control" name="sondeqiqe">
                      <option value="1">Normal Xeber</option>
                      <option value="2">Son deqiqe xdberi</option>
                    </select>
                  </div>
                </div>   
              </div>
                 <div class="box-body">
                  <div class="form-group">
                  <label class="col-sm-2 control-label">Xeber Tag</label>
                  <div class="col-sm-7">
                   <input type="text" value="" name="tag" class="form-control"  >
                  </div>
                </div>   
              </div>
              <div class="box-footer">
           <a class="btn btn-warning" href="<?php echo base_url('admin/xeberler'); ?>">Imtina Et</a>
              <button type="submit" class="btn btn-primary pull-right">Elave Et</button>
              </div>
            </form>
          </div>
          </div>
      </section>
      <div class="clearfix"></div>
         

