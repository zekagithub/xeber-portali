 <section class="content">
<div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-newspaper-o"></i></span>
            <div class="info-box-content">
              <span class="info-box-text">Xəbər sayisi</span>
              <?php $xebercek=xebercek(); ?>
              <span class="info-box-number"><?php echo $xebercek; ?><small>ədəd</small></span>
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-edit"></i></span>
            <div class="info-box-content">
              <span class="info-box-text">Redaktor<br> sayisi</span>
              <?php $redaktorcek=redaktorcek(); ?>
              <span class="info-box-number"><?php echo $redaktorcek; ?><small>ədəd</small></span>
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-television"></i></span>
            <div class="info-box-content">
              <span class="info-box-text">Reklam</span>
              <?php $reklamsayi=reklamsayi(); ?>
              <span class="info-box-number"><?php echo $reklamsayi; ?><small>ədəd</small></span>
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-facebook"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Sosial Mediya<br> hesabi</span>
              <?php $smediyasayi=smediyasayi(); ?>
              <span class="info-box-number"><?php echo $smediyasayi; ?><small>ədəd</small></span>
            </div>
          </div>
        </div>
          <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-comments-o"></i></span>
            <div class="info-box-content">
              <?php $status=1;$status=commentsayi($status); ?>
            <span class="info-box-text">Təsdiq edilmiş<br> şərh</span>
              <span class="info-box-number"><?php echo $status; ?><small>ədəd</small></span>
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-comments-o"></i></span>
            <div class="info-box-content">
              <span class="info-box-text">Təsdiq<br> edilməmiş<br> şərh</span>
              <?php $estatus=0;$estatus=commentsayi($estatus); ?>
              <span class="info-box-number"><?php echo $estatus; ?><small>ədəd</small></span>
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-envelope-o"></i></span>
            <div class="info-box-content">
              <span class="info-box-text">Oxunmuş <br>mesaj sayısı</span>
              <?php $status=1;$status=mesajsayi($status); ?>
              <span class="info-box-number"><?php echo $status; ?><small>ədəd</small></span>
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-envelope-o"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Oxunmamış <br>mesaj sayısı</span>
              <?php $estatus=0;$estatus=mesajsayi($estatus); ?>
              <span class="info-box-number"><?php echo $estatus; ?><small>ədəd</small></span>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
      </div>

    </section>