<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$route['default_controller'] = 'anasehife';
$route['anasehife/(:num)']='anasehife';
$route['siyasetdetal/(:any)']='anasehife/siyasetdetal/$1';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
